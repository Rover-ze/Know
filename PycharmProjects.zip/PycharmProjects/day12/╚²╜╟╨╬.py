# class Parent(object):
#     x = 1
#
#
# class Child1(Parent):
#     pass
#
#
# class Child2(Parent):
#     pass
#
#
# print(Parent.x, Child1.x, Child2.x)
#
# Child1.x = 3
# print(Parent.x, Child1.x, Child2.x)
#
# Parent.x = 4
# print(Parent.x, Child1.x, Child2.x)


# list = ['a', 'b', 'c', 'd', 'e']
# print(list[10:])


# list = [32, 5, 18, 119, 2, -15]
# for i in range(len(list)-1, 0, -1):
#     for j in range(i):
#         if list[j] > list[j + 1]:
#             list[j], list[j + 1] = list[j + 1], list[j]
# print(list)


# def quick_sort(alist, start, end):
#     """快速排序"""
#
#     # 递归的退出条件
#     if start >= end:
#         return
#
#     # 设定起始元素为要寻找位置的基准元素
#     mid = alist[start]
#
#     # low为序列左边的由左向右移动的游标
#     low = start
#
#     # high为序列右边的由右向左移动的游标
#     high = end
#
#     while low < high:
#         # 如果low与high未重合，high指向的元素不比基准元素小，则high向左移动
#         while low < high and alist[high] >= mid:
#             high -= 1
#         # 将high指向的元素放到low的位置上
#         alist[low] = alist[high]
#
#         # 如果low与high未重合，low指向的元素比基准元素小，则low向右移动
#         while low < high and alist[low] < mid:
#             low += 1
#         # 将low指向的元素放到high的位置上
#         alist[high] = alist[low]
#
#     # 退出循环后，low与high重合，此时所指位置为基准元素的正确位置
#     # 将基准元素放到该位置
#     alist[low] = mid
#
#     # 对基准元素左边的子序列进行快速排序
#     quick_sort(alist, start, low - 1)
#
#     # 对基准元素右边的子序列进行快速排序
#     quick_sort(alist, low + 1, end)
#
#
# alist = [54, 26, 93, 17, 77, 31, 44, 55, 20]
# quick_sort(alist, 0, len(alist) - 1)
# print(alist)


# def func_a():
#     global x
#     print('x is', x)
#     x = 2
#     print('changed local x to', x)
#
#
# x = 50
# func_a()
# print('value of x is', x)
#
#
# def func_b(x):
#     print('x is', x)
#     x = 2
#     print('changed local x to', x)
#
#
# x = 50
# func_b(x)
# print('value of x is', x)

# list = []
# for i in range(1, 101):
#     if i % 3 != 0:
#         list.append(i)
# print(list)
#
# list1 = []
# for i in range(1, 101, 3):
#     list1.append(i)
# for j in range(2, 101, 3):
#     list1.append(j)
# list1.sort()
# print(list1)
#
# list2 = [i for i in range(1, 101)]
# for x in range(len(list2)-1, 0, -1):
#     if list2[x] % 3 == 0:
#         del list2[x]
# print(list2)


def deco(func):
    def wrapper():
        print('%s is begin' % (func.__name__))
        func()
        print('%s is end' % (func.__name__))

    return wrapper


@deco
def foo():
    print('in foo():')
    # print('i have a para: %s' % x)

foo()

