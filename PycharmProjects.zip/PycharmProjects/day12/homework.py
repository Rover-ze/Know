# 1、定义一个类描述分数（1/4,4/5），提供加减乘除运算。化简，分母不为0.（（运算符重载
# """
# class Number(object):
#
#     def __init__(self, numerator, denominator):
#         self._numerator = numerator
#         self._denominator = denominator
#
#     @property
#     def denominator(self):
#         return self._denominator
#
#     @denominator.setter
#     def denominator(self, denominator):
#         if self._denominator != 0:
#             self._denominator = denominator
#
#     @property
#     def numerator(self):
#         return self._numerator
#
#     @numerator.setter
#     def numerator(self, numerator):
#         self._numerator = numerator
#
#     def add(self, other):
#         self._numerator = self._numerator * other.denominator + other.numerator * self._denominator
#         self._denominator = self._denominator * other.denominator
#         return (self._numerator, self._denominator)
#
#     def sut(self, other):
#         self._numerator = self._numerator * other.denominator - other._numerator * self._denominator
#         self._denominator = self._denominator * other.denominator
#
#     def mul(self, other):
#         self._numerator = self._numerator * other._numerator
#         self._denominator = self._denominator * other._denominator
#
#     def div(self, other):
#         self._numerator = self._numerator * other._denominator
#         self._denominator = self._denominator * other._numerator
#
#     def __str__(self):
#         if self._denominator / gcd(abs(self._numerator), abs(self._denominator)) == 1:
#             return '%d' % (self._numerator / gcd(abs(self._numerator), abs(self._denominator)))
#         return '%d / %d' % (self._numerator / gcd(abs(self._numerator), abs(self._denominator)),
#                             self._denominator / gcd(abs(self._numerator), abs(self._denominator)))
#
#
# def gcd(x, y):
#     """计算最大公约数"""
#     (x, y) = (y, x) if x > y else (x, y)
#     for factor in range(x, 0, -1):
#         if x % factor == 0 and y % factor == 0:
#             return factor
#
#
# def lcm(x, y):
#     """计算最小公倍数"""
#     return x * y // gcd(x, y)
#
#
# def main():
#     num1 = Number(1, 10)
#
#     num2 = Number(5, 21)
#
#     num1.sut(num2)
#
#     print(num1)
#
#
# if __name__ == '__main__':
#     main()
# """

from math import gcd


class Fraction(object):

    def __init__(self, num, den):
        if den == 0:
            raise ValueError('分母不能为0')
        self._num = num
        self._den = den
        # self.normalize()
        # self.simplify()

    @property
    def num(self):
        return self._num

    @property
    def den(self):
        return self._den

    def add(self, other):
        return Fraction(self._num * other.den + other.num * self._den,
                        self._den * other.den).simplify().normalize()
                        # 开火车式 / 级联编程

    def sub(self, other):
        return Fraction(self._num * other.den - other.num * self._den,
                        self._den * other.den).simplify().normalize()

    def mul(self, other):
        return Fraction(self._num * other.num, self._den * other.den)\
            .simplify().normalize()

    def div(self, other):
        return Fraction(self._num * other.den, other.num * self._den)\
            .simplify().normalize()

    def __add__(self, other):
        return self.add(other)

    def __sub__(self, other):
        return self.sub(other)
    # 运算符重写 ：
    # 运算符重载 ：
    # 级联编程 ：

    def __mul__(self, other):
        return self.mul(other)

    def __truediv__(self, other):
        return self.div(other)

    def simplify(self):
        if self._num != 0 and self._den != 1:
            factor = gcd(abs(self._num), abs(self._den))
            if factor > 1:
                self._num //= factor
                self._den //= factor
        return self # 返回自身

    def normalize(self):
        if self._den < 0:
            self._num = -self._num
            self._den = -self._den
        return self

    def __str__(self):
        if self._num == 0:
            return '0'
        elif self._den == 1:
            return str(self._num)
        else:
            return '%d/%d' % (self._num, self._den)


def main():
    f1 = Fraction(-3, 6)
    f2 = Fraction(1, 5)
    f3 = Fraction(0, 5)
    print(f1 - f2)
    print(f1 * f2)
    print(f1 / f2)


if __name__ == '__main__':
    main()






