from multiprocessing import Process
import os
import time
# process 线程
# thread  进程

"""
def output():
    print(os.getpid())   # 显示进程标识号
    while True:
        print('Pong', end=' ', flush=True)  # flush 取消缓存
        time.sleep(0.01)


def main():
    print(os.getpid())
    p = Process(target=output)
    p.start()
    while True:
        print('Ping', end=' ', flush=True)
        time.sleep(0.01)


if __name__ == '__main__':
    main()
"""


count = 0


def output(string):
    global count
    while count < 10:
        print(string, end=' ', flush=True)
        count += 1
        # sleep(0.01)


def main():
    t1 = Process(target=output, args=('Ping', ))
    t1.start()
    t2 = Process(target=output, args=('Pong', ))
    t2.start()


if __name__ == '__main__':
    main()