import subprocess


def main():
    subprocess.call('calc')
    subprocess.call('notepad')
    subprocess.call('python 多进程.py')


if __name__ == '__main__':
    main()