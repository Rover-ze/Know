# 创建线程的两种方式：
# 1、直接创建Thread对象并通过target参数指定线程启动后要执行的任务
# 2、继承Thread自定义线程，通过重写run方法指定线程启动后执行的任务


from threading import Thread


"""
count = 0

def output(string):
    global count
    inner_count = 0
    while count < 100:
        print(string, end=' ', flush=True)
        count += 1
        inner_count += 1
    print('\n%s打印了%d次' % (string, inner_count))


def main():
    t1 = Thread(target=output, args=('Ping', ))
    t1.start()
    t2 = Thread(target=output, args=('Pong', ))
    t2.start()


if __name__ == '__main__':
    main()
"""


# 启动五个线程向同一个列表中追加内容，每个线程10000个，统计列表中是不是放了5万个
# 五辆车，五个线程控制他们向终点跑

from threading import Thread


class PrintThread(Thread):

    def __init__(self, string, count):
        super().__init__()
        self._string = string
        self._count = count

    def run(self):
        for _ in range(self._count):
            print(self._string, end=' ', flush=True)
            # flush = True 简单来讲就是取消缓存，将内容直接输出到屏幕上


def main():
    PrintThread('Ping', 100).start()
    PrintThread('Pong', 100).start()


if __name__ == '__main__':
    main()

