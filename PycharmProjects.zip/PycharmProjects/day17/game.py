from random import randint

import pygame
from threading import Thread


class Game(object):

    def __init__(self, x, y, color=(0, 0, 0)):
        self._x = x
        self._y = y
        self._color = color


class Wall(Game):

    def __init__(self, x, y, length, width, color):
        super().__init__(x, y, color)
        self._length = length
        self._width = width

    def draw(self, screen):
        pygame.draw.rect(screen, self._color, (self._x, self._y, self._width, self._length), 5)

        for index in range(5):
            pygame.draw.line(screen, self._color, [10, 106 + 96 * index], [1190, 106 + 96 * index], 3)


class Car(Game):
    def __init__(self, x, y, length, width, color, speed):
        super().__init__(x, y, color)
        self._length = length
        self._width = width
        self._speed = speed

    def draw(self, screen):
        pygame.draw.rect(screen, self._color, (self._x, self._y, self._width, self._length), 15)

    def move(self):
        self._x += randint(1, 10)
        x = self._x
        sx = self._speed
        self._x = x + sx
        # self._y = y + sy
        # if x + self._width >= 800 or x - self._width <= 0:
        #     self._speed = -sx, sy
        # if y + self._width >= 600 or y - self._width <= 0:
        #     self._speed = sx, -sy


def main():
    # def refresh():
    #     screen.fill([100, 180, 50])
    #     wall.draw(screen)
    #     for car in cars:
    #         car.draw(screen)
    #     pygame.display.flip()

    # wall = Wall(10, 10, 480, 1180, [50, 50, 50])

    cars = []
    for index in range(5):
        car = Car(30, 50 + 120 * index, 40, 20, [200, 50, 50], 10)

    pygame.init()

    pygame.display.set_caption('Speed')
    screen = pygame.display.set_mode([1200, 500])
    screen.fill([100, 180, 50])
    for car in cars:
        car.draw(screen)
    pygame.display.flip()
    # clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        #
        #     speed = 10
        #     car1 = Car(30, 50, 20, 20, [200, 50, 50], speed)
        # refresh()
        # clock.tick(20)
        # car1.move()

    pygame.quit()





if __name__ == '__main__':
    main()