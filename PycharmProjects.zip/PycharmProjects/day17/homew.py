# 启动五个线程向同一个列表中追加内容，每个线程10000个，统计列表中是不是放了5万个
# 五辆车，五个线程控制他们向终点跑

from threading import Thread

list1 = []


class PrintThread(Thread):

    def __init__(self, string, count):
        super().__init__()
        self._string = string
        self._count = count

    def run(self):
        for _ in range(self._count):
            list1.append(self._string)


def main():
    PrintThread('A', 10000).start()
    PrintThread('B', 10000).start()
    PrintThread('C', 10000).start()
    PrintThread('D', 10000).start()
    PrintThread('E', 10000).start()
    print(list1)
    print(len(list1))


if __name__ == '__main__':
    main()
