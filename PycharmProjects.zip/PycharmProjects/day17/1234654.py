# def bubble_sort(alist):
#     for j in range(len(alist) - 1, 0, -1):
#         # j表示每次遍历需要比较的次数，是逐渐减小的
#         for i in range(j):
#             if alist[i] > alist[i + 1]:
#                 alist[i], alist[i + 1] = alist[i + 1], alist[i]
#
#
# li = [54, 26, 93, 17, 77, 31, 44, 55, 20]
# bubble_sort(li)
# print(li)


#
# from functools import wraps
# from time import time
#
#
# def record(output):
#     def decorate(func):
#         @wraps(func)
#         def wrapper(*args, **kwargs):
#             start = time()
#             func(*args, **kwargs)
#             end = time()
#             output('函数%s的执⾏行行时间: %.3f秒' % (func.__name__, end - start))
#
#         return wrapper
#
#     return decorate
#
#
# @record
# def foo():
#     for i in range(5):
#         print(i)


# def dedup(items: list) -> list:
#
#     new_items = []
#     seen = set()
#     for item in items:
#         if item not in seen:
#             new_items.append(item)
#             seen.add(item)
#     return new_items


# def main():
#     l = dedup([1, 2, 4, 3, 2, 1])
#     print(l)
#
#
# if __name__ == '__main__':
#     main()






