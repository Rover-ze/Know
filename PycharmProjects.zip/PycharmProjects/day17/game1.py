from random import randint
import time
import pygame
from threading import Thread


class Game(object):

    def __init__(self, x, y, color=(0, 0, 0)):
        self._x = x
        self._y = y
        self._color = color


class Wall(Game):

    def __init__(self, x, y, length, width, color):
        super().__init__(x, y, color)
        self._length = length
        self._width = width

    def draw(self, screen):
        pygame.draw.rect(screen, self._color, (self._x, self._y, self._width, self._length), 5)

        for index in range(5):
            pygame.draw.line(screen, self._color, [10, 106 + 96 * index], [1190, 106 + 96 * index], 3)


class Car(Game):
    def __init__(self, x, y, length, width, color, speed):
        super().__init__(x, y, color)
        self._length = length
        self._width = width
        self._speed = speed

    def draw(self, screen):
        pygame.draw.rect(screen, self._color,
                         (self._x, self._y, 40, 20), 0)

    def move(self):
        if self._x < 1150:
            self._x += randint(0, 20)

# def car_color:


def main():
    class BackgroundTask(Thread):

        def run(self):

            while True:
                screen.fill([100, 180, 50])
                pygame.draw.line(screen, [0, 0, 0], (80, 10), (80, 490), 4)
                wall.draw(screen)
                for car in cars:
                    car.draw(screen)
                pygame.display.flip()
                time.sleep(0.05)

                for car in cars:
                    car.move()

    wall = Wall(10, 10, 480, 1180, [50, 50, 50])

    cars = []
    for index in range(5):
        car = Car(30, 50 + 95 * index, 20, 40, [200, 50, 50], 10)
        cars.append(car)
    pygame.init()
    pygame.display.set_caption('Speed')
    screen = pygame.display.set_mode([1200, 500])
    BackgroundTask(daemon=True).start()


    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False


    pygame.quit()





if __name__ == '__main__':
    main()