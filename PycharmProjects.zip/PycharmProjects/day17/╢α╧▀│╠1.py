from threading import Thread


def output(string):
    while True:
        print(string, end=' ', flush=True)


def main():
    t1 = Thread(target=output, args=('Ping',), daemon=True)
    t1.start()
    t2 = Thread(target=output, args=('Pong',), daemon=True)
    # damon=True -- 将线程设置为守护器
    # 守护线程 -- 不值得保留的线程 -- 其他线程如果都执行完毕了，守护线程自动结束
    t2.start()


if __name__ == '__main__':
    main()
