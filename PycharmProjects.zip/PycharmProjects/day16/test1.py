# 正则表达式  -- 定义字符串的匹配模式

#
def is_valid_username(username):

    if 6 <= len(username) <= 20:
        for ch in username:
            if not('0' <= ch <= '9' or 'A' <= ch <= 'Z'
                   or 'a' <= 'z' or ch == '_'):
                return False
        return True
    return False


def main():
    print(is_valid_username('admin'))
    print(is_valid_username('123admin'))


if __name__ == '__main__':
    main()

print('a\n')
print('a\\n')
print(r'\n')    #  r 转义字符，\n安字符输出


import re

def main():
    username = 'jackfrued'
    m = re.match(r'\w{6,20}', username)
    print(m)
    if m:
        print(m.span())   # 取出匹配范围
        print(m.group())  # 取出匹配的部分


if __name__ == '__main__':
    main()

