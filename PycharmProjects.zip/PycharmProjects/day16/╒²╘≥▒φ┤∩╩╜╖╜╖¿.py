import re


def main():
    # substitute -- 替换
    sentence = '马化腾我操你大爷干你二爷Fuck你三舅爷'
    pure = re.sub('[操艹草顶日干]|马化腾|fuck', '*', sentence,
                  flags=re.IGNORECASE)
    # flags=re.IGNORECASE  标记，忽略大小写
    print(pure)

    # split -- 撕开，撕裂
    sentence = 'You go your way, I will go mine!'
    mylist = re.split(r'[ ,!]', sentence)
    print(mylist)

    # map函数 -- 高阶函数，映射，
    # findall --
    content = 'abc123hello456good879hi'
    mylist = re.findall(r'\d+', content)
    mylist = list(map(int, mylist))
    # mylist = list(map(int, re.findall(r'\d+', content)))
    print(sum(mylist) / len(mylist))



if __name__ == '__main__':
    main()


    # group --