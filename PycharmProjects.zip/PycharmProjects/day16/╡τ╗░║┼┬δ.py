import re


# def main():
#     number = input('请输入数字：')
    # m1 = re.match(r'^13\d{9}$', number)
    # m2 = re.match(r'^14[57]\d{8}$', number)
    # m3 = re.match(r'^15[0-3,5-9]\d{8}$', number)
    # m4 = re.match(r'^17[6-8]\d{8}$', number)
    # m5 = re.match(r'^18\d{9}$', number)
    #
    # if m1 or m2 or m3 or m4 or m5:

#     m1 = re.match(r'^(13[0-9]|14[57]|15[012356789]|17[678]|18[0-9])\d{8}$', number)
#     if m1:
#         print('这是一个电话号码')
#     else:
#         print('这不是一个电话号码')
#
#
# if __name__ == '__main__':
#     main()


def main():
    pattern = re.compile(r'1[345789]\d{9}')
    # pattern = re.compile(r'(?<=\D)1[345789]\d{9}(?=\D)')
    sentence = '我的手机号是13548752589不是13025668548，小怪兽的手机号是13325648574，不是110'
    m = pattern.search(sentence)
    while m:
        print(m.group())
        # m = pattern.search(sentence, m.span()[1])
        m = pattern.search(sentence, m.end())


if __name__ == '__main__':
    main()
