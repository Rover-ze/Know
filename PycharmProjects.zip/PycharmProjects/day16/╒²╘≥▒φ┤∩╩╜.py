import re


def main():
    username = input('请输入用户名：')
    qq = input('请输入QQ:')
    # m1 = re.match(r'^[0-9a-zA-Z]{6,20}', username)
    patternl = re.compile(r'^[0-9a-zA-Z]{6,20}')
    m1 = patternl.match(username)
    if not m1:
        print('请输入有效用户名')
    m2 = re.match(r'^[1-9]\d{4,11}$', qq)
    if not m2:
        print('请输入有效QQ号')
    if m1 and m2:
        print('你输入的信息是有效的！')

    # m1 = re.match(r'\w{1,9}', username)
    # m2 = re.match(r'\d{4,11}', qq)
    # if m1 and m2:
    #
    #     print('欢迎')
    # else:
    #     print('用户名或QQ号错误')


if __name__ == '__main__':
    main()
