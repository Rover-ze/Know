# 如果一个类有多个父类，儿多个父类又有公共父类（菱形继承/钻石继承）
# 那么在搜索属性和方法时搜索的依据是C3算法（有点类似广度优先搜索）
# 这是python3 中的一个改进，在此之前搜索优先的是深度搜索（DFS）

# 实际开发中尽量避免多重继承，
from abc import ABCMeta, abstractmethod


class Father(object):

    def __init__(self, name):
        self._name = name

    def drink(self):
        print(self._name + '正在喝二锅头')

    def gamble(self):
        print(self._name + '正在赌博')


class Monk(Father, metaclass=ABCMeta):

    # def __init__(self, nickname):
    #     self._nickname = nickname

    @abstractmethod
    def drink(self):
        pass

    @abstractmethod
    def eat(self):
        pass


class Musician(Father, classmethod=ABCMeta):

    # def __init__(self, art_name):
    #     self._art_name = art_name

    @abstractmethod
    def drink(self):
        pass

    @abstractmethod
    def play(self):
        pass


class Son(Father, Monk, Musician):

    def __init__(self, name, nickname, art_name):
        Father.__init__(self._name)
        self._nickname = nickname
        self._art_name = art_name

    def drink(self):
        print(self._nsme + '正在喝啤酒')

    def eat(self):
        print(self._nickname + '正在吃斋')

    def play(self):
        print(self._art_name + '正在谈钢琴')

def main():
    son = Son('123', '225', '256')
    son.eat()



if __name__ == '__main__':
    main()















