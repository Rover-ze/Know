import re


def main():
    number = input('请输入数字：')
    m1 = re.match(r'^\d{3}$', number)
    # 任意三位数字
    m2 = re.match(r'^14\d{3}$', number)
    # 14开头后接任意三位数字
    m3 = re.match(r'^\w{2}\d{3}$', number)
    # 任意两个字符（大小写字母和符号）及三个数字

    if m1 or m2 or m3:
        print('这是一个有效字符串')
    else:
        print('这是一无效字符串')


if __name__ == '__main__':
    main()
