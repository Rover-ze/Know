# import sys
# #
# # f = list(range(1, 10))
# # f1 = [x for x in range(1, 10) if x % 2 == 0]
# # print(f)
# # print(f1)
# #
# # f = [x ** 2 for x in range(1, 10)]
# # f1 = [x ** x for x in range(1, 10)]
# # print(f)
# # print(f1)
# # print(sys.getsizeof(f))
#
# # f = (x ** 2 for x in range(1, 10))
# # print(sys.getsizeof(f))
# # print(f)
# # for val in f:
# #     print(val)
# #
# # print(sys.getsizeof(f))
# def fib(n):
#     a, b = 0, 1
#     for _ in range(n):
#         a, b = b, a + b
#         yield a
#
#
# for val in fib(20):
#     print(val)
#
# if __name__ == '__main__':
#     fib(1)
#
#
# def fab(max):
#     n, a, b = 0, 0, 1
#     # while n < max:
#     # print(b)
#     a, b = b, a + b
#     # n = n + 1
#     print(b)
#
#
# if __name__ == '__main__':
#     fab(5)
#


def main(n=5):
    a = 0
    b = 1
    for _ in range(n):
        print(b)
        a, b = b, a + b
        # print(a)


    # c, a, b = 0, 0, 1
    # while c < n:
    #     print(b)
    #     a, b = b, a + b
    #     c = c + 1
    #     # print(b)

if __name__ == '__main__':
    main(5)
