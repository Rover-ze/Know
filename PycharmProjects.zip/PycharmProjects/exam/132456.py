def is_leap_year(year):
    return year % 4 == 0 and year % 100 != 0 or year % 400 == 0


def w(year):
    list1 = []
    list2 = []
    c = year // 100
    y = year % 100

    for m in range(1, 13):
        print('\t\t\t%s月' % m, end='\n')
        print('日\t一\t二\t三\t四\t五\t六')
        print()

        if m == 1:
            m = 13
            y2 = y - 1
            for d in range(1, 32):
                w = (y2 + y2 // 4 + c // 4 - 2 * c + 26 * (m + 1) // 10 + d - 1) % 7
                list1.append(w)
                list2.append(d)

        if m == 2:
            m = 14
            y1 = y - 1
            if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
                for d in range(1, 30):
                    w = (y1 + y1 // 4 + c // 4 - 2 * c + 26 * (m + 1) // 10 + d - 1) % 7
                    list1.append(w)
                    list2.append(d)
            else:
                for d in range(1, 29):
                    w = (y1 + y1 // 4 + c // 4 - 2 * c + 26 * (m + 1) // 10 + d - 1) % 7
                    list1.append(w)
                    list2.append(d)

        if m == 3 or m == 5 or m == 7 or m == 8 or m == 10 or m == 12:
            for d in range(1, 32):
                w = (y + y // 4 + c // 4 - 2 * c + 26 * (m + 1) // 10 + d - 1) % 7
                list1.append(w)
                list2.append(d)

        if m == 4 or m == 6 or m == 9 or m == 11:
            for d in range(1, 31):
                w = (y + y // 4 + c // 4 - 2 * c + 26 * (m + 1) // 10 + d - 1) % 7
                list1.append(w)
                list2.append(d)

        result = day.calcFirstday(m)
        if result >= 1:
            print(' \t' * (result - 1), end='\t')
        else:
            pass
        for h in range(1, year[m - 1] + 1):
            print(h, end='\t')
            result += 1
            if result % 7 == 0:
                print(' ', end='\n')
        print('', end='\n\n')


    return list1


def main():
    year = int(input('请输入哪一年：'))
    print(w(year))


if __name__ == '__main__':
    main()
