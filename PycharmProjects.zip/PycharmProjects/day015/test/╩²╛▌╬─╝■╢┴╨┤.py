# 文件读写

# 异常机制 -- 处理程序在运行过程中出现的意外状况的手段
# 因为不是所有的问题都能在写程序调试程序的时候就能发现

# 打开文件 --> 判断大小 --> 分配内存 --> 读取文件 --> 关闭文件

"""
def main():
    # 正常读写
    fs = open('hello', 'r', encoding='utf-8')     # 和fs.close同时出现
    # 相对路径(相对目前的路径)、绝对路径（完整的文件路径）
    content = fs.read()     # 读取
    print(content)
    fs.close()


if __name__ == '__main__':
    main()
"""

"""
import time


def main():
    # 循环，一行一行的打印
    fs = open('hello', 'r', encoding='utf-8')
    for line in fs:
        print(line, end='')
        time.sleep(1)
    fs.close()


if __name__ == '__main__':
    main()
"""

"""
def main():
    # 在列表中读写
    fs = open('hello', 'r', encoding='utf-8')
    mylist = fs.readlines()
    print(mylist)
    fs.close()


if __name__ == '__main__':
    main()
"""

"""
def main():
    with open('hello', 'r', encoding='utf-8') as fs:
        # 加了 with as 语法，在文件读取完成后自动关闭。
        mylist = fs.readlines()   # 读取多行
        print(mylist)
    # ('../abc/hello.txt') --> 一个'.'表示当前路径，两个'..'表示上级路径。


if __name__ == '__main__':
    main()
"""

"""
import time

def main():
    try:  # 把可能出现状况的文件保护起来，

        with open('hello', 'r', encoding='utf-8') as fs:
            for line in fs:
                print(line, end='\n')
                time.sleep(1)

    except (FileNotFoundError, IOError):  # 如果文件出现状况，except捕捉异常。
             #  (文件路径,  读写错误)
        print('指定文件无法打开')

    print('程序执行程序')


if __name__ == '__main__':
    main()
"""

"""
import time

def main():
    try:  # 把可能出现状况的文件保护起来，

        with open('helo', 'r', encoding='utf-8') as fs:
            for line in fs:
                print(line, end='\n')
                time.sleep(1)

    except FileNotFoundError as e:  # 如果文件出现状况，except捕捉异常。
        print(e)   # 如果文件异常，打印错误提示
        print('指定文件无法打开')

    print('程序执行程序')


if __name__ == '__main__':
    main()
"""