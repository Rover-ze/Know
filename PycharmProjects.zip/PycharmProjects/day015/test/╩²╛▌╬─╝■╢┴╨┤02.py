def main():
    try:
        with open('hello.txt', 'w', encoding='utf-8') as fs:
            fs.write('我想做燕子')
            fs.write('只需简单思想')

    except (FileNotFoundError, IOError):

        print('指定文件无法打开')

    print('程序执行程序')


if __name__ == '__main__':
    main()