# BASE64编码


def main():
    try:
        with open('../123/q.JPG', 'rb') as fs1:  # 把图片转移成二进制格式
            data = fs1.read()
            print(data)
            print(type(data))
        with open('../abc/hi.jpg', 'wb') as fs2:  # 把二进制格式图片存入新的文件夹中，
            fs2.write(data)   # 写数据
    except FileNotFoundError as e:
        print(e)
        print('指定的文件无法打开')
    except IOError:
        print('读写文件时出现错误')
    print('程序执行结束')


if __name__ == '__main__':
    main()