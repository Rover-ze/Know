from math import sqrt


def is_prime(n):
    assert n > 0   # 断言：保证条件成立
    for factor in range(2, int(sqrt(n)) + 1):
        if n % factor == 0:
            return False
    return True if n != 1 else False


def main():
    filenames = ('a.txt', 'b.txt', 'c.txt')
    fs_list = []
    try:
        for filename in filenames:
            fs_list.append(open(filename, 'w', encoding='utf-8'))
        for number in range(1, 10000):
            if is_prime(number):
                if number < 100:
                    fs_list[0].write(str(number) + '\n')
                elif number < 1000:
                    fs_list[1].write(str(number) + '\n')
                else:
                    fs_list[2].write(str(number) + '\n')
    except IOError:
        # 如果try中出现了状况就通过except来捕获错误（异常）进行对应的处理
        print('读写文件发生错误')
    else:
        # 如果没有出状况那么可以把无风险的代码放到else中执行
        pass

    finally:
        # 不管程序正常还是异常最后这里代码一定执行
        # 所以此处最适合做释放外部资源的操作
        print('释放文件资源')
        for fs in fs_list:
            fs.close()
    print('程序运行完成')


if __name__ == '__main__':
    main()