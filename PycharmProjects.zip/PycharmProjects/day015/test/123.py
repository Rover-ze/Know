# URL - Uniform Resource Locator

import requests
import json


def main():
    # request / response  # 请求 / 响应
    resp = requests.get('http://api.tianapi.com/meinv/?key=2eb12de72bfc81a657273e01885c272b&num=10')
    mydict = json.loads(resp.text)    # load --> 加载文件  loads --> 加载字符串
    for tempdict in mydict['newslist']:
        pic_url = tempdict['picUrl']
        resp = requests.get(pic_url)
        filename = pic_url[pic_url.rfind('/') + 1:]
        try:
            with open(filename, 'wb') as fs:
                fs.write(resp.content)
        except IOError as e:
            print(e)


if __name__ == '__main__':
    main()
