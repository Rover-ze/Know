# import json
#
#
# def main():
#     mydict = {
#         'name': '王大锤',
#         'age': '38',
#         'qq': 258948548,
#         'friends': ['白元芳', '周星星'],
#         'car': [
#             {'brand': 'Auto', 'max_speed': 120},
#             {'brand': 'QQ', 'max_speed': 80},
#             {'brand': 'Benz', 'max_speed': 250}
#         ]
#     }
#     try:
#         with open('data.json', 'w', encoding='utf-8') as fs:
#             json.dump(mydict, fs)
#     except FileNotFoundError as e:
#         print(e)
#         print('指定的文件无法打开')
#     except IOError:
#         print('读写文件时出现错误')
#     print('程序执行结束')
#
#
# if __name__ == '__main__':
#     main()

import json


def main():
    try:
        with open('data.json', 'r', encoding='utf-8') as fs:
            yourdict = json.load(fs)
            print(yourdict)
    except IOError as e:
        print(e)


if __name__ == '__main__':
    main()