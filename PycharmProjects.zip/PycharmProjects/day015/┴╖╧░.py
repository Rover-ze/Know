# def is_palindrome(num):
#     """
#     判断一个数是不是回文数
#     :param num: 一个非负整数
#     :return: 是回文数返回True否则返回False
#     """
#     temp = num
#     total = 0
#     while temp > 0:
#         total = total * 10 + temp % 10
#         temp //= 10
#     return num == total
#
#
# print(is_palindrome(122))
# print(is_palindrome(121))
#
#
# print(231 % 10)

mydict={"a":1,"b":2,"c":3}


mydict_new={}
for key,val in mydict.items():
    mydict_new[val]=key


print(mydict_new)