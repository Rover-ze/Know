
# 1、21根火柴游戏，轮流拿（1-4）。拿到最后一根的输。（保证计算机赢）

# from random import randint
#
# match = 21
#
# while match > 0:
#     x = int(input('你拿走火柴数：'))
#     match = match - x
#     if match == 0:
#         print('你输了')
#         break
#     y = randint(1, 4)
#     if y >= match:
#         y = randint(1, match)
#     print('电脑拿走火柴数：', y)
#     match = match - y
#     print('剩余火柴数量：', match)
#     if match == 0:
#         print('你赢了')
#         break





# def main():
#     total = 21
#     while total > 0:
#         print('总共还剩%d根火柴。' %total)
#         while True:
#             num = int(input('拿几根火柴：'))
#             if 1 <= num <= 4 and num <= total:
#                 break
#         total -= num
#         if total > 0:
#             print('计算机拿走了%d根火柴'  % (5 - num))
#             total -= 5 - num
#     print('你拿到了最后一根火柴，你输了！')
#
#
# if __name__ == '__main__':
#     main()



def main():
    total = 21
    while total > 0:
        print('剩余火柴根数')
        while True:
            num = input('你拿走了%d根火柴' % num)
            if 1 <= num <= 4 and num <= total:
                break
        total -= num














# match = 21
# while match > 0:
#     x = int(input('你拿走火柴数：'))
#     match = match - x
#     if match <= 0:
#         print('你输了')
#         break
#     y = 5 - x
#     print('电脑拿走火柴数：', y)
#     match = match - y
#     print('剩余火柴数量：', match)
#     if match <= 0:
#         print('你赢了')
#         break
#     if match == 0:
#         break


















