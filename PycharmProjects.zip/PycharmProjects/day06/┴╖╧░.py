from 函数练习 import gcd

if __name__ == '__main__':
    print(gcd(5, 10))
    print(gcd(10, 20))

# 写一个函数：判断一个数字是不是回文数：12321、2684862、11、121
# 判断一个数字是不是回文素数

def is_palindrome(num):
    """
    判断一个数字是不是回文数
    :param num: 一个正整数
    :return: 是回文数返回True不是返回False

    """
    temp = num
    total = 0
    while temp > 0:
        total = total * 10 + temp % 10
        temp //= 10
    return total == num


if __name__ == '__main__':
    print(is_palindrome(121))
    print(is_palindrome(12345678987654321))