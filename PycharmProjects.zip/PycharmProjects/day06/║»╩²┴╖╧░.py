"""
from random import randint


# 定义判断素数的函数
def is_prime(num):
    for x in range(2, num):
        if num % x == 0:
            return False
    return True


#通过下面的if条件可以在导入模块时候不去执行下面的代码，不影响代码在本文件中的运行。
if __name__ == '__main__':
    print(is_prime(6))
    print(is_prime(7))
    print(is_prime(100))
    print(is_prime(13))

"""


# 计算最大公约数
def gcd(x, y):
    """
    计算最大公约数
    :param x: 变量x
    :param y: 变量y
    :return: 最大公约数
    """
    if x > y:
        x, y = y, x   # 也可写成：x, y = y, x if x > y else x, y
    for factor in range(x, 0, -1):
        if y % factor == 0 and x % factor == 0:
            return factor

if __name__ == '__main__':
    print(gcd(14,28))


"""
#计算最小公倍数
def lcm(x, y):
    for z in range(x, x * y + 1):
        if z % x == 0 and z % y ==0:
            return z


print(lcm(50, 2))
"""

if __name__ == '__main__':
    def lcm(x, y):
        return x * y // gcd(x, y)


    print(lcm(5, 10))





# def is_palindrome(num):
#     """
#     判断一个数是不是回文数
#     :param num: 一个非负整数
#     :return: 是回文数返回True否则返回False
#     """
#     temp = num
#     total = 0
#     while temp > 0:
#         total = total * 10 + temp % 10
#         temp //= 10
#     return num == total
#
# print(is_palindrome(122))
# print(is_palindrome(121))
#
#
# print(231 % 10)