
"""
# 定义求阶乘的函数 - 将求阶乘的功能抽取出来放到函数中
# 注意：定义函数时需要与前、后代码空格两行
def f(x):
    y = 1
    for z in range(1, x + 1):
        y *= z
    return y


m = int(input('m = '))
n = int(input('n = '))
# 当需要计算阶乘的时候不用写循环而是直接调用已经定义好的函数
print(f(m) // f(n) // f(m - n))

"""


"""
from random import randint

# 定义摇n个骰子，求和
def roll_dice(n=2):   # 2表示默认值，当赋值后执行赋值数。
    total = 0
    for _ in range(n):
        total += randint(1, 6)
    return total


n = 3
money = 1000

# 玩家有钱游戏就可以继续
while money > 0:
    print('玩家总资产：', money)
    # 通过while循环判断玩家下注是否有效。
    while True:
        use_money = int(input('请下注：'))
        if 0 < use_money <= money:
            break

    a = roll_dice(n)
    print(a)
    go_on = False
    if a == 7 or a == 11:
        print(a, '恭喜你。')
        money += use_money
    elif a == 2 or a == 3 or a == 12:
        print(a, '你输了。')
        money = money - use_money
    else:
        go_on = True
    while go_on:
        b = roll_dice(n)
        print(b)
        if b == 7:
            print(b, '你输了。')
            money = money - use_money
            go_on = False
        elif b == a:
            print(b, '恭喜你。')
            money += use_money
            go_on = False
    print(money)
    if use_money > money:
        print('你没钱了')
"""

"""
#可变参数，函数的参数可以是任意的个数


def add(* args):
    totle = 0
    for x in args:
        totle += x
    return totle


print(add(1))
print(add(1, 2, 5, 10))
"""


def is_palindrome(num):
    """
    判断一个数是不是回文数
    :param num: 一个非负整数
    :return: 是回文数返回True否则返回False
    """
    temp = num
    total = 0
    while temp > 0:
        total = total * 10 + temp % 10
        temp //= 10
    return num == total

print(is_palindrome(122))
print(is_palindrome(121))


print(231 % 10)



# n! = n * (n - 1)!