#!/usr/bin/python
# -*- coding=utf-8 -*-

import xml.dom.minidom

# 打开xml文档
dom = xml.dom.minidom.parse('/work/code/LOC/LOC_translation/ViveFocus_Settings/LOC/string_fr.xml')

# 得到文档元素对象
root = dom.documentElement

def change():
     # 获取标签的属性值
    itemlist = root.getElementsByTagName('string')
    for x in range(len(itemlist)):
        item = itemlist[x]
        un = item.getAttribute('name')
        print(un)

print(change())
