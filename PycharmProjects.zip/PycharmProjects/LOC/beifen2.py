#!/usr/bin/python
# -*- coding=utf-8 -*-

import xml.dom.minidom



# 打开xml文档
dom = xml.dom.minidom.parse('/work/code/LOC/LOC_translation/ViveFocus_Settings/LOC/string_fr.xml')

# 得到文档元素对象
root = dom.documentElement

# def judge():
#     cc = dom.getElementsByTagName('string')
#     c1 = cc[0]
#     return(c1.firstChild.data)
# print judge()


def change():
    #  获取标签的属性值
    itemlist = root.getElementsByTagName('string')
    print(len(itemlist))
    for x in range(len(itemlist)):
        item = itemlist[x ]
    # item = itemlist[0]
        un = item.getAttribute('name')
        print(un)
        # return un
    # return un
    # pd = item.getAttribute('password')
    # print pd

    # ii = root.getElementsByTagName('string')
    # i1 = ii[0]
    # i = i1.getAttribute('name')
    # print i

    # i2 = ii[1]
    # i = i2.getAttribute('id')
    # return i

print(change())
#
# itemlist = root.getElementsByTagName('string')
# item = itemlist[0]
# un = item.getAttribute('name')
# print un
#
# # pd = item.getAttribute('password')
# # print pd
#
# ii = root.getElementsByTagName('string')
# i1 = ii[0]
# i = i1.getAttribute('name')
# print i