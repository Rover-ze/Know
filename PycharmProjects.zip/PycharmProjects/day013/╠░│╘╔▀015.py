import pygame
from abc import ABCMeta, abstractmethod
from random import randint

BLACK_COLOR = (0, 0, 0)
GREEN_COLOR = (0, 250, 0)
FOOD_COLOR = (120, 180, 50)

UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3


class GameObject(object, metaclass=ABCMeta):

    def __init__(self, x=0, y=0, color=BLACK_COLOR):
        self._x = x
        self._y = y
        self._color = color

    @property
    def x(self):
        return self._x

    @property
    def y(self):
        return self._y

    @abstractmethod
    def draw(self, screen):
        pass


class Wall(GameObject):

    def __init__(self, x, y, width, height, color=BLACK_COLOR):
        super().__init__(x, y, color)
        self._width = width
        self._height = height

    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height

    def draw(self, screen):
        pygame.draw.rect(screen, self._color,
                         (self._x, self._y, self._width, self._height), 4)


class Food(GameObject):

    def __init__(self, x, y, size, color=FOOD_COLOR):
        super().__init__(x, y, color)
        self._size = size
        self._hidden = False

    def draw(self, screen):
        if not self._hidden:
            pygame.draw.circle(screen, self._color,
                               (self._x + self._size // 2, self._y + self._size // 2),
                               self._size // 2, 0)
        self._hidden = not self._hidden


class SnakeNode(GameObject):

    def __init__(self, x, y, size, color=GREEN_COLOR):
        super().__init__(x, y, color)
        self._size = size

    @property
    def size(self):
        return self._size

    def draw(self, screen):
        pygame.draw.rect(screen, self._color,
                         (self._x, self._y, self._size, self._size), 0)
        pygame.draw.rect(screen, BLACK_COLOR,
                         (self._x, self._y, self._size, self._size), 1)


class Snake(GameObject):

    def __init__(self):
        super().__init__()
        self._dir = LEFT
        self._nodes = []
        self._eat_food = False
        for index in range(2):
            node = SnakeNode(290 + index * 20, 290, 20)
            self._nodes.append(node)

    @property
    def dir(self):
        return self._dir

    @property
    def head(self):
        return self._nodes[0]

    def change_dir(self, new_dir):
        if (self._dir + new_dir) % 2 != 0:
            self._dir = new_dir

    def move(self):
        head = self._nodes[0]   # 开始的蛇头
        snake_dir = self._dir
        x, y, size = head.x, head.y, head.size
        if snake_dir == UP:
            y -= size
        elif snake_dir == RIGHT:
            x += size
        elif snake_dir == DOWN:
            y += size
        else:
            x -= size
        new_head = SnakeNode(x, y, size)
        self._nodes.insert(0, new_head)
        if self._eat_food:
            self._eat_food = False
        else:
            self._nodes.pop()

    def collide(self, wall):
        """
        撞墙

        :param wall:围墙
        :return:撞到围墙返回True，否则返回False
        """
        head = self._nodes[0]
        return head.x < wall.x or head.x + head.size > wall.x + wall.width \
               or head.y < wall.y or head.y + head.size > wall.y + wall.height

    def eat_food(self, food):
        if self.head.x == food.x and self.head.y == food.y:
            self._eat_food = True

    def draw(self, screen):
        for node in self._nodes:
            node.draw(screen)


def main():

    def refresh():
        """刷新游戏窗口"""
        # 函数的嵌套，在函数里添加函数
        screen.fill((230, 230, 230))
        wall.draw(screen)
        food.draw(screen)
        snake.draw(screen)
        pygame.display.flip()

    def handle_key_event(key_event):
        """按键事件"""
        key = key_event.key
        new_dir = snake.dir
        if key == ord('w'):
            new_dir = UP
        elif key == ord('d'):
            new_dir = RIGHT
        elif key == ord('s'):
            new_dir = DOWN
        elif key == ord('a'):
            new_dir = LEFT
        if new_dir != snake.dir:
            snake.change_dir(new_dir)

    def create_egg():
        row = randint(0, 29)
        col = randint(0, 29)
        return Food(10 + 20 * col, 10 + 20 * row, 20)

    wall = Wall(10, 10, 600, 600)
    food = create_egg()
    snake = Snake()
    pygame.init()

    screen = pygame.display.set_mode((620, 620))
    pygame.display.set_caption('贪吃蛇')
    screen.fill((230, 230, 230))
    pygame.display.flip()    # 刷新窗口，设置的背景颜色显示出来
    clock = pygame.time.Clock()  # 设置时间帧数，让画面连续起来
    # 循环保证窗口保留
    running = True
    game_over = False
    while running:
        for event in pygame.event.get():   # 事件处理
            if event.type == pygame.QUIT:  # 如果你关闭了窗口，循环结束
                running = False
            elif event.type == pygame.KEYDOWN:
                handle_key_event(event)

        if not game_over:
            refresh()  # 没在for循环中
        clock.tick(3)
        if not game_over:
            snake.move()
            if snake.collide(wall):
                game_over = True
                snake.eat_food(food)

    pygame.quit()


if __name__ == '__main__':
    main()
