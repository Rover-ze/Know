import pygame


class Ball(object):

    def __init__(self, x, y, color, radius, sx, sy): # 数据抽象
        self._x = x
        self._y = y
        self._color = color
        self._radius = radius
        self._sx = sx
        self._sy = sy   # sy 移动速度

    def move(self):    # 行为抽象,小球移动
        self._x += self._sx
        self._y += self._sy
        if self._x + self._radius >= 800 or self._x - self._radius <= 0:
            self._sx = -self._sx
        if self._y + self._radius >= 600 or self._y - self._radius <= 0:
            self._sy = -self._sy

    def draw(self, screen):   # 小球画小球，屏幕，颜色。坐标，半径，0是实心1是空心
        pygame.draw.circle(screen, self._color, (self._x, self._y),
                           self._radius, 0)


def main():
    pygame.init()
    screen = pygame.display.set_mode([800, 600])
    bg_color = (242, 242, 242)
    red_color = (255, 0, 0)
    ball = Ball(100, 100, red_color, 30, 30, 3)
    pygame.display.set_caption('大球吃小球')
    clock = pygame.time.Clock()  # 时间，让球动起来
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill(bg_color)  # 重复填充背景颜色
        ball.draw(screen)
        pygame.display.flip()  # 刷新窗口
        clock.tick(24)
        ball.move()

    pygame.quit()


if __name__ == '__main__':
    main()