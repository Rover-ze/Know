from abc import ABCMeta, abstractmethod
from random import randint
import pygame

BLACK_COLOR = (0, 0, 0)
GREEN_COLOR = (0, 255, 0)
FOOD_COLOR = (230, 185, 185)

UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3


class GameObject(object, metaclass=ABCMeta):

    def __init__(self, x=0, y=0, color=BLACK_COLOR):
        self._x = x
        self._y = y
        self._color = color

    @property
    def x(self):
        return self._x

    @property
    def y(self):
        return self._y

    @abstractmethod
    def draw(self, screen):
        pass


class Wall(GameObject):

    def __init__(self, x, y, width, height, color=BLACK_COLOR):
        # 墙的属性：左上角坐标，宽，高，颜色（默认为黑色
        super().__init__(x, y, color)   # 从父类处继承
        self._width = width
        self._height = height

    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height

    def draw(self, screen):
        # 画墙
        pygame.draw.rect(screen, self._color,
                         (self._x, self._y, self._width, self._height), 4)


class Food(GameObject):

    def __init__(self, x, y, size, color=FOOD_COLOR):
        # 食物（蛋）的属性：坐标，尺寸，颜色
        super().__init__(x, y, color)
        self._size = size
        self._hidden = False  # 食物是否显示/隐藏

    def draw(self, screen):  # 画食物
        if not self._hidden:  # 如果食物没隐藏，画出食物
            pygame.draw.circle(screen, self._color,
                               (self._x + self._size // 2, self._y + self._size // 2),
                               self._size // 2, 0)     # ？？？？
        self._hidden = not self._hidden   # ？？？？


class SnakeNode(GameObject):

    def __init__(self, x, y, size, color=GREEN_COLOR):
        super().__init__(x, y, color)
        self._size = size

    @property
    def size(self):
        return self._size

    def draw(self, screen):  # 蛇身每一节
        pygame.draw.rect(screen, self._color,
                         (self._x, self._y, self._size, self._size), 0)
        pygame.draw.rect(screen, BLACK_COLOR,
                         (self._x, self._y, self._size, self._size), 1)


class Snake(GameObject):

    def __init__(self):
        super().__init__()
        self._dir = LEFT   # 设置初始化方向为左
        self._nodes = []   # 创建列表放蛇的每一节
        self._alive = True  # 判断蛇是否活的
        for index in range(5):
            node = SnakeNode(290 + index * 20, 290, 20)   # 每一节的坐标和尺寸（半径？）
            self._nodes.append(node)    # 把每一个节点添加至列表nodes中，组成蛇

    @property
    def dir(self):
        return self._dir

    @property
    def alive(self):
        return self._alive

    @property
    def head(self):
        return self._nodes[0]   # 开始的蛇头

    def change_dir(self, new_dir):   # 改变方向
        if (self._dir + new_dir) % 2 != 0:
            self._dir = new_dir

    def move(self):
        """蛇移动，前进"""
        if self._alive:  # 判断如果蛇是活的
            snake_dir = self._dir
            x, y, size = self.head.x, self.head.y, self.head.size
            if snake_dir == UP:
                y -= size
            elif snake_dir == RIGHT:
                x += size
            elif snake_dir == DOWN:
                y += size
            else:
                x -= size
            new_head = SnakeNode(x, y, size)
            self._nodes.insert(0, new_head)  # 在坐标0号位置放入一个新的节点（nodes列表中）
            self._nodes.pop()                # 删除列表最后一个元素

    def collide(self, wall):
        """
        撞墙

        :param wall: 围墙
        """
        head = self.head
        if head.x < wall.x or head.x + head.size > wall.x + wall.width \
                or head.y < wall.y or head.y + head.size > wall.y + wall.height:
            # 节点（矩形）的坐标点为左上方的点
            self._alive = False

    def eat_food(self, food):
        if self.head.x == food.x and self.head.y == food.y:
            tail = self._nodes[-1]
            self._nodes.append(tail)  # 切片处理尾巴，加一节点至蛇尾巴后
            return True
        return False

    def eat_me(self):
        pass

    def draw(self, screen):  # 此处生成蛇会一直生成

        for node in self._nodes:
            node.draw(screen)


def main():
    # 函数的嵌套，在函数里添加函数
    def refresh():
        """刷新游戏窗口"""
        screen.fill((242, 242, 242))   # 填充屏幕颜色
        wall.draw(screen)     # 画墙
        food.draw(screen)     # 画食物
        snake.draw(screen)    # 画蛇
        pygame.display.flip()  # 刷新屏幕，把上面画的东西显示在窗口

    def handle_key_event(key_event):
        """处理按键事件"""
        key = key_event.key
        if key == pygame.K_F2:
            reset_game()   # 按F2重新开始游戏
        elif key in (pygame.K_a, pygame.K_w, pygame.K_d, pygame.K_s):
            if snake.alive:
                new_dir = snake.dir
                if key == pygame.K_w:
                    new_dir = UP
                elif key == pygame.K_d:
                    new_dir = RIGHT
                elif key == pygame.K_s:
                    new_dir = DOWN
                elif key == pygame.K_a:
                    new_dir = LEFT
                if new_dir != snake.dir:
                    snake.change_dir(new_dir)

    def create_food():  # 创造食物
        row = randint(0, 29)
        col = randint(0, 29)
        return Food(10 + 20 * col, 10 + 20 * row, 20)

    def reset_game():  # 重新设定游戏
        nonlocal food, snake  # nonlocal -- 非局部的，global -- 全体的
        food = create_food()
        snake = Snake()

    wall = Wall(10, 10, 600, 600)
    food = create_food()
    snake = Snake()
    # 引用墙、食物、蛇
    pygame.init()
    screen = pygame.display.set_mode((620, 620))
    pygame.display.set_caption('贪吃蛇')
    screen.fill((242, 242, 242))

    pygame.display.flip()      # 刷新窗口，设置的背景颜色显示出来

    clock = pygame.time.Clock()  # 设置时间帧数，让画面连续起来

    running = True
    while running:   # 循环保证窗口保留
        for event in pygame.event.get():    # 事件处理（抓取事件
            if event.type == pygame.QUIT:   # 如果你关闭了窗口，循环结束
                running = False
            elif event.type == pygame.KEYDOWN:   # 键盘事件（键盘操作）
                handle_key_event(event)
        if snake.alive:
            refresh()      # 刷新窗口（没在for循环中）
        clock.tick(3)     # 设置时间帧数，让画面连续起来
        if snake.alive:
            snake.move()
            snake.collide(wall)
            # snake.eat_me(nade)
            if snake.eat_food(food):
                food = create_food()

    pygame.quit()


if __name__ == '__main__':
    main()
