total = 1
for x in range(1, 11):
    total *= x
print(total)