import pygame

EMPTY = 0
BLACK = 1
WHITE = 2
black_color = [0, 0, 0]
white_color = [255, 255, 255]
# 常量，赋值

class RenjuBoard(object):

    def __init__(self):
        self._board = [[]] * 15
        self.reset()

    def reset(self):
        for row in range(len(self._board)):
            self._board[row] = [EMPTY] * 15

    def move(self, row, col, is_black):
        if self._board[row][col] == EMPTY:
            self._board[row][col] = BLACK if is_black else WHITE
            return True
        return False

    def draw(self, screen):
        for index in range(15):
            pygame.draw.line(screen, black_color,
                             [20, 20 + 40 * index], [580, 20 + 40 * index], 1)
            # 化线段(屏幕， 颜色， 起点， 终点， 线段粗细)

            pygame.draw.line(screen, black_color,
                             [20 + 40 * index, 20], [20 + 40 * index, 580], 1)

        pygame.draw.rect(screen, black_color, [10, 10, 580, 580], 4)
        # 画边框（rect）   （10，10） - 左上角矩形边框坐标；  580 - 矩形宽度和高度
        pygame.draw.circle(screen, black_color, [300, 300], 6, 0)  # 画天元（circle）
        pygame.draw.circle(screen, black_color, [140, 140], 6, 0)  # 画四角圆点
        pygame.draw.circle(screen, black_color, [140, 460], 6, 0)
        pygame.draw.circle(screen, black_color, [460, 140], 6, 0)
        pygame.draw.circle(screen, black_color, [460, 460], 6, 0)
        for row in range(len(self._board)):
            for col in range(len(self._board[row])):
                if self._board[row][col] != EMPTY:
                    ccolor = black_color \
                        if self._board[row][col] == BLACK else white_color
                    pos = [20 + 40 * col, 20 + 40 * row]
                    pygame.draw.circle(screen, ccolor, pos, 16, 0)
        pygame.display.flip()


def main():
    # board = [[EMPTY] * 15 for _ in range(15)]  # 创建列表容纳棋子
    # board[7][7] = BLACK
    # board[8][7] = WHITE
    board = RenjuBoard()
    is_black = True
    pygame.init()  # 初始化，同下面的pygame.quit()成对出现
    pygame.display.set_caption('五子棋')  # 修改名字
    screen = pygame.display.set_mode([600, 600])   # 创建窗口
    screen.fill([200, 200, 200])   # 颜色依次为红、绿、蓝，光的三原色
    board.draw(screen)
    pygame.display.flip()    # 刷新窗口：填上指定东西后
    running = True
    while running:  # 处理事件（鼠标点击，键盘录入等等）
        for event in pygame.event.get():   # 在event模块中的函数get，拿到pygame中的所有事件。
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN \
                    and event.button == 1:  # 鼠标操作, 鼠标左键
                x, y = event.pos
                if 20 <= x <= 580 and 20 <= y <= 580:
                    col = round((x - 20) / 40)
                    row = round((y - 20) / 40)
                    if board.move(row, col, is_black):
                        # 判断胜负
                        is_black = not is_black
                        screen.fill([200, 200, 200])
                        board.draw(screen)
                        pygame.display.flip()
    pygame.quit()  # 退出


if __name__ == '__main__':
    main()
