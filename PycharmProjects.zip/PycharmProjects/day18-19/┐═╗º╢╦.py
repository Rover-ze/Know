from socket import socket
from threading import Thread


def main():
    client = socket()
    client.connect(('10.7.189.71', 2048))

    while True:

        data = client.recv(1024)
        t2 = Thread(target=print(data.decode('utf-8')), daemon=True)
        t2.start()

        A = str(input('请输入：'))
        t1 = Thread(target=client.send(('Rose:%s' %A).encode('utf-8')), daemon=True)
        t1.start()



if __name__ == '__main__':
    main()
