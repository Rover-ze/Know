from socket import socket, AF_INET, SOCK_STREAM
from datetime import datetime
# SOCK_DGRAM -- UDP
# SOCK_STREAM -- DCP


def main():
    # 创建一个基于TCP协议的套接字对象（服务器）
    # 因为我们做的是应用级的产品或服务，所以可以利用现有的传输服务来实现数据传输
    server = socket()
    # 绑定IP地址（网络上主机的身份标识）和端口（用于区分不同服务的IP地址的扩展）
    server.bind(('10.7.189.71', 2048))
    # 开始监听客户端的连接，（512代表此服务器最大连接数目。（合适就好））
    server.listen(512)
    print('服务器已经启动正在监听...')
    #
    while True:
        # 通过accept方法接收客户端的连接
        # accept方法是一个阻塞式的方法，如果没有客户端连上来
        # 那么accept方法就会让代码阻塞，知道有客户连接成功才返回
        # accept方法返回一个元组，元组中的第一个值是代表客户端的对象
        # 元组中的第二个值又是一个元组，其中有客户端的IP地址和客户端的端口
        # client = server.accept()
        # print(client)
        client, addr = server.accept()
        print(addr, '连接成功')
        # encode -- 编码
        client.send('hello'.encode('utf-8'))

        client.send(str(datetime.now()).encode('utf-8'))
        client.close()


if __name__ == '__main__':
    main()
