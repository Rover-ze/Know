from socket import socket, SOCK_DGRAM


def main():
    # UDP -- 用户数据报协议
    sender = socket(type=SOCK_DGRAM)
    with open('aa.jpg', 'rb') as f:
        data = f.read
    sender.sendto(data, address=)


if __name__ == '__main__':
    main()
