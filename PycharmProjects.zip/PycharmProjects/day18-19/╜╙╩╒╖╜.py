from socket import socket, SOCK_STREAM


def main():
    receiver = socket(type=SOCK_STREAM)
    data = bytes()
    while True:
        receiver.recvfrom(1024)
