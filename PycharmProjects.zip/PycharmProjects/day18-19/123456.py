from smtplib import SMTP


def main():
    sender = SMTP('smtp.163.com')
    sender.login('18380498522@163.com', 'xz102887')


if __name__ == '__main__':
    main()