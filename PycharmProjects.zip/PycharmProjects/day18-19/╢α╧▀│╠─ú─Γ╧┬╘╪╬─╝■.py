import time
import random
from multiprocessing import Process   # 多进程
from threading import Thread  # 多线程

# 如果多个任务之间没有任何的关联（独立的子任务）而且希望利用CPU的多核特性
# 那么我们推荐使用多进程
# Information Technology -- IT
# 摩尔定律


def download(filename):
    print('开始下载%s...' % filename)
    delay = random.randint(5, 15)
    time.sleep(delay)
    print('%s下载完成，用时%d秒.' % (filename, delay))


def main():
    # start = time.time()
    # download('python从入门到住院.pdf')
    # download('Pekin Hot.avi')
    # end = time.time()
    # print('总共耗时%f秒' % (end - start))

    # start = time.time()
    # p1 = Process(target=download, args=('python从入门到住院.pdf', ))
    # p1.start()
    # p2 = Process(target=download, args=('Pekin Hot.avi', ))
    # p2.start()
    # p1.join()
    # p2.join()    # 等待进程结束
    # end = time.time()
    # print('总共耗时%f秒' % (end - start))

    start = time.time()
    t1 = Thread(target=download, args=('python从入门到住院.pdf', ))
    t1.start()
    t2 = Thread(target=download, args=('Pekin Hot.avi', ))
    t2.start()
    t1.join()
    t2.join()    # 等待进程结束
    end = time.time()
    print('总共耗时%f秒' % (end - start))


if __name__ == '__main__':
    main()