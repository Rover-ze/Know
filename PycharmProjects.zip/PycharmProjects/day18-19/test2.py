import time
from threading import Thread, Lock


class Account(object):

    def __init__(self):
        self._balance = 0
        self._lock = Lock()

    @property
    def balance(self):
        return self._balance

    def deposit(self, money):
        # 当多个线程同时访问一资源的时候，就有可能应为竞争资源导致资源的状态错误
        # 当多个线程访问资源我们通常称之为临界资源，对临界资源的访问需要加上保护
        if money > 0:
            self._lock.acquire()   # (acquire)获得lock,保护资源
            try:
                new_balance = self._balance + money
                time.sleep(0.01)
                self._balance = new_balance
            finally:
                self._lock.release()


class AddMoneyThread(Thread):

    def __init__(self, account):
        super().__init__()
        self._account = account

    def run(self):
        self._account.deposit(1)


def main():
    account = Account()
    tlist = []
    for _ in range(100):
        t = AddMoneyThread(account)
        tlist.append(t)
        t.start()
    for t in tlist:
        t.join()
    print('账户余额：%d元' % account.balance)


if __name__ == '__main__':
    main()
