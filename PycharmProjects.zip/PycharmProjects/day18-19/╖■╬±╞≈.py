from socket import socket
from threading import Thread
# from socketserver


def main():
    server = socket()
    server.bind(('10.7.189.71', 2048))
    server.listen(512)

    client, addr = server.accept()
    print(addr, '连接成功')

    while True:

        A = str(input('请输入：'))
        # client.send(('Jack:%s' %A).encode('utf-8'))
        t1 = Thread(target=client.send(('Jack:%s' %A).encode('utf-8')), daemon=True)
        t1.start()

        data = client.recv(1024)
        t2 = Thread(target=print(data.decode('utf-8')), daemon=True)
        t2.start()


if __name__ == '__main__':
    main()
