import time
import random
from multiprocessing import Process   # 多进程
from threading import Thread  # 多线程


# def download(filename):
#     print('开始下载%s...' % filename)
#     delay = random.randint(5, 15)
#     time.sleep(delay)
#     print('%s下载完成，用时%d秒.' % (filename, delay))


class DownloadTask(Thread):
    # 创建类

    def __init__(self, filename):
        super().__init__()
        self._filename = filename

    # 钩子函数(hook) / 回调函数(callback)  自己不掉，等待其他程序调
    # 知道会做什么，知道怎么做，但是不知道具体执行时间时用
    def run(self):  # 定义方法，必须用run
        # download(self._filename)
        print('开始下载%s...' % self._filename)
        delay = random.randint(5, 15)
        time.sleep(delay)
        print('%s下载完成，用时%d秒.' % (self._filename, delay))


def main():
    start = time.time()
    t1 = DownloadTask('python从入门到住院.pdf')
    t1.start()
    t2 = DownloadTask('Pekin Hot.avi')
    t2.start()
    t1.join()
    t2.join()    # 等待进程结束
    end = time.time()
    print('总共耗时%f秒' % (end - start))


if __name__ == '__main__':
    main()