from socket import socket


def main():
    client = socket()
    client.connect(('10.7.189.71', 2048))
    # 接收数据
    data = client.recv(1024)
    print(data.decode('utf-8'))


if __name__ == '__main__':
    main()