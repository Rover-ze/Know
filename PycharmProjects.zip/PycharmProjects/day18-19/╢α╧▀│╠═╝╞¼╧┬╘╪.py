import requests
import json
import time
from threading import Thread


class DownlodeTask(Thread):

    def __init__(self, url):
        super().__init__()
        self._url = url

    def run(self):
        resp = requests.get(self._url)
        filename = self._url[self._url.rfind('/') + 1:]


def run():
    resp = requests.get('http://api.tianapi.com/meinv/?key=2eb12de72bfc81a657273e01885c272b&num=10')
    mydict = json.loads(resp.text)  # load --> 加载文件  loads --> 加载字符串
    for tempdict in mydict['newslist']:
        pic_url = tempdict['picUrl']

        try:
            with open(filename, 'wb') as fs:
                fs.write(resp.content)
        except IOError as e:
            print(e)


def main():
    start = time.time()
    t1 = run()
    t1.start()
    t2 = run()
    t2.start()


    end = time.time()
    use_time = end - start
    print(use_time)


if __name__ == '__main__':
    main()
