from random import randint, choice


class Ultraman(object):

    __slots__ = ('_name', '_hp', '_mp')
    # 限定ultraman类的属性个数

    def __init__(self, name, hp, mp):
        self._name = name
        self._hp = hp
        self._mp = mp

    @property
    def name(self):
        return self._name

    @property
    def hp(self):
        return self._hp

    @hp.setter
    def hp(self, hp):
        self._hp = hp if hp >= 0 else 0

    def attack(self, monster):
        monster.hp -= randint(15, 25)

    def huge_attack(self, monster):
        if self._mp >= 50:
            self._mp -= 50
            injury = monster.hp * 3 // 4
            injury = injury if injury >= 50 else 50
            monster.hp -= injury
        else:
            self.attack(monster)

    def magic_attack(self, monsters):
        if self._mp >= 20:
            self._mp -= 20
            for monster in monsters:
                monster.hp -= randint(10, 15)

    def __str__(self):  # 打印对象时，把对象直接以字符串形式表现出来
        return '%s奥特曼\n' % self._name + \
               '生命值：%d\n' % self._hp + \
               '魔法值：%d\n' % self._mp


class Monster(object):

    def __init__(self, name, hp):
        self._name = name
        self._hp = hp

    @property
    def name(self):
        return self._name

    @property
    def hp(self):
        return self._hp

    @hp.setter
    def hp(self, hp):
        self._hp = hp if hp >= 0 else 0

    def attack(self, ultraman):
        ultraman.hp -= randint(10, 20)

    def __str__(self):
        return '%s小怪兽\n' % self._name + \
               '生命值:%d\n' % self._hp


def main():
    u = Ultraman('孙悟空', 1000, 120)
    print(u)
    m1 = Monster('红孩儿', 250)
    m2 = Monster('铁扇', 400)
    m3 = Monster('牛魔王', 600)
    ms = [m1, m2, m3]
    print(*ms)
    attack_round = 1
    while (m1.hp > 0 or m2._hp > 0 or m3._hp > 0) and u.hp > 0:
        print('====第%d回合====' % attack_round)

        u.attack(choice(ms))
        # u.magic_attack(choice(ms))
        # u.huge_attack(ms)

        for m in ms:
            if m.hp > 0:
                m.attack(u)
        print(u)
        print(*ms)
        attack_round += 1
    if u.hp > 0:
        print('%s奥特曼胜利！' % u.name)
    else:
        print('小怪兽胜利！')


if __name__ == '__main__':
    main()


# 完善游戏。