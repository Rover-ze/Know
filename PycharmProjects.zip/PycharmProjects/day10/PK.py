"""
import os


def print_board(board):
    print(board['TL'] + '|' + board['TM'] + '|' + board['TR'])
    print('-+-+-')
    print(board['ML'] + '|' + board['MM'] + '|' + board['MR'])
    print('-+-+-')
    print(board['BL'] + '|' + board['BM'] + '|' + board['BR'])


def main():
    init_board = {
        'TL': ' ', 'TM': ' ', 'TR': ' ',
        'ML': ' ', 'MM': ' ', 'MR': ' ',
        'BL': ' ', 'BM': ' ', 'BR': ' '
    }
    begin = True
    while begin:
        curr_board = init_board.copy()
        begin = False
        turn = 'x'
        counter = 0
        os.system('clear')
        print_board(curr_board)
        while counter < 9:
            move = input('轮到%s走棋, 请输入位置: ' % turn)
            if curr_board[move] == ' ':
                counter += 1
                curr_board[move] = turn
                if turn == 'x':
                    turn = 'o'
                else:
                    turn = 'x'
            os.system('clear')
            print_board(curr_board)
        choice = input('再玩一局?(yes|no)')
        begin = choice == 'yes'


if __name__ == '__main__':
    main()
"""

"""
class pk(object):

    def __init__(self, o_hp=100, o_mp=50, g1_hp=100, g2_hp=100, g3_hp=100):
        self.o_hp = o_hp
        self.o_mp = o_mp
        self.g1_hp = g1_hp
        self.g2_hp = g2_hp
        self.g3_hp = g3_hp

    def pk(self):
        a = 20
        b = 50
        c = 10
        d = 20

        while True:
            total = 0
            print('回合%d' % total)
            skill = input('奥特曼使用' )
            if skill == a:
                self.g1_hp -= 20
            if skill == a:
                self.g2_hp -= 20
            if skill == a:
                self.g3_hp -= 20
            if skill == b:
                self.o_mp -= 30
                self.g1_hp -= 50
                self.g2_hp -= 50
                self.g3_hp -= 50
            if self.g1_hp == 0 and self.g2_hp == 0 and self.g3_hp == 0:
                break
            g_shill = print('小怪兽g1使用')
            if g_shill == c:
                self.o_hp -= 10
            if g_shill == d:
                self.o_hp -= 20
            if self.o_hp ==0:
                break
            g_shill = print('小怪兽g2使用')
            if g_shill == c:
                self.o_hp -= 10
            if g_shill == d:
                self.o_hp -= 20
            if self.o_hp == 0:
                break
            g_shill = print('小怪兽g3使用')
            if g_shill == c:
                self.o_hp -= 10
            if g_shill == d:
                self.o_hp -= 20
            if self.o_hp == 0:
                break

            break

def main():
    pass

if __name__ == '__main__':
    main()
"""

"""
from random import randint


class Ultraman(object):

    __slots__ = ('_name', '_hp', '_mp')
    # 限定ultraman类的属性个数

    def __init__(self, name, hp, mp):
        self._name = name
        self._hp = hp
        self._mp = mp

    @property
    def name(self):
        return self._name

    @property
    def hp(self):
        return self._hp

    @hp.setter
    def hp(self, hp):
        self._hp = hp if hp >= 0 else 0

    def attack(self, monster):
        monster.hp -= randint(15, 25)

    def huge_attack(self, monster):
        if self._mp >= 50:
            self._mp -= 50
            injury = monster.hp * 3 // 4
            injury = injury if injury >= 50 else 50
            monster.hp -= injury
        else:
            self.attack(monster)

    def magic_attack(self, monsters):
        if self._mp >= 20:
            self._mp -= 20
            for monster in monsters:
                monster.hp -= randint(10, 15)

    def __str__(self):  # 打印对象时，把对象直接以字符串形式表现出来
        return '%s奥特曼\n' % self._name + \
               '生命值：%d\n' % self._hp + \
               '魔法值：%d\n' % self._mp


class Monster(object):

    def __init__(self, name, hp):
        self._name = name
        self._hp = hp

    @property
    def name(self):
        return self._name

    @property
    def hp(self):
        return self._hp

    @hp.setter
    def hp(self, hp):
        self._hp = hp if hp >= 0 else 0

    def attack(self, ultraman):
        ultraman.hp -= randint(10, 20)

    def __str__(self):
        return '%s小怪兽\n' % self._name + \
               '生命值:%d\n' % self._hp


def main():
    u = Ultraman('孙悟空', 1000, 120)
    print(u)
    m = Monster('牛魔王', 250)
    print(m)
    attack_round = 1
    while u.hp > 0 and m.hp > 0:
        print('====第%d回合====' % attack_round)
        u.attack(m)
        if m.hp > 0:
            m.attack(u)
        print(u)
        print(m)
        attack_round += 1
    if u.hp > 0:
        print('%s奥特曼胜利！' % u.name)
    else:
        print('%s小怪兽胜利！' % m.name)


if __name__ == '__main__':
    main()


# 完善游戏。
"""


foo = ['a', 'b', 'c', 'd', 'e']
from random import choice
print(choice(foo))