# 类、
# 类是对象的蓝图和末班，有了类就可以创建对象（（抽象，（人类）
# 定义类需要做两件事情：数据抽象和行为抽象
# 数据抽象 -- 抽取对象共同的静态特征（名词）-- 属性
# 行为抽象 -- 抽取对象共同的动态特征（找动词） -- 方法

# 定义类的关键字是 -- class -- 类名（每个单词首字母大写）

# 对象，具体，（人类中的每一个个体）（静态特征，动态特征）

# 我们定义一个类实际上是吧数据和操作数据的函数绑定到一起
# 形成一个逻辑上的整体，这个整体就叫做对象
# 而且将来任何时候想使用这种对象时直接服用这个类就可以了

# 拿到需求，先提取名词及动词


# 1.定义类型：用class + 名字。（名字的首字母用大写）
class Student(object):       # 定义学生对象,

    # 构造方法（构造器/构造子 -- constructor）
    # 调用该方法的时候，不是直接使用方法的名字，而是使用类的名字
    def __init__(self, _name, _age):                # 初始化，指定对象的特征（指定学生的年龄和名字）
        # 给对象绑定属性
        self._name = _name  # self._name = name 不表示不允许更改name参数
        self._age = _age

    # 我们定义一个方法就代表对象可以接收这个消息
    # 对象的方法第一个参数统一用self
    # 它代表了接收消息的对象 -- 对象.消息（参数）
    def study(self, course):     # 类里面的方法，是学生对象的行为.self-->表示正在接收消息的对象。
        print('%s正在学习%s' % (self._name, course))

    def watch_tv(self):
        if self._age >= 16:
            print('%s正在观看电视' % self._name)
        else:
            print('我们推荐%s观看熊出没' % self._name)


def main():
    # 2.调用构造方法，创建学生对象
    # 实际上调用的是Student类找中——init——方法
    stu1 = Student('王大锤', 18)       # '='前是应用，后面是对象
    stu1._name = '白元芳'
    # 3.给对象发消息
    # 通过给对象发消息让对象完成某些工作
    # 解决任何问题都是通过让对象去做事情
    stu1.study('python程序设计')
    stu2 = Student('周星星', 15)
    stu2.study('HTML网页设计')
    stu2.watch_tv()


if __name__ == '__main__':
    main()





"""
class Student:       # 定义学生对象,

    def study(self, course):     # 类里面的方法，是学生对象的行为.self-->表示正在接收消息的对象。
        print('%s正在学习%s' % (self.name, course))

    def watch_tv(self):
        print('%s正在观看电视' % self.name)


def main():
    stu1 = Student()       # '='前是应用，后面是对象
    stu1.name = '王大锤'
    stu1.study('python程序设计')
    stu2 = Student()
    stu2.name = '周星星'
    stu2.study('HTML网页设计')
    stu2.watch_tv()


if __name__ == '__main__':
    main()
"""

print(123)                  # 十进制
print(0x123)      # 十六进制
print(0o123)    # 八进制
print(0b111)   # 二进制

