
# 改造时间，获取系统时间

# 倒计时时间，倒计时完成后提醒：时间到。

# 定义一个类，描述平面上的点：可以移动这个点（坐标）移动到，移动了，以及两点间的距离。

# 猜数字游戏

# 博客

# 奥特曼打小怪兽游戏：

"""
from math import sqrt
class Point(object):

    def __init__(self, x=0, y=0):
        self._x = x
        self._y = y

    def move_to(self, x, y):
        self._x = x
        self._y = y

    def move_by(self, dx, dy):
        self._x += dx
        self._y += dy

    def distance_to(self, other):
        dx = self._x - other._x
        dy = self._y - other._y
        return sqrt(dx ** 2 + dy ** 2)

    def __str__(self):
        return '（%s, %s）' % (str(self._x), str(self._y))


def main():
    p1 = Point(3.2, 5.1)
    p2 = Point()
    print(p1)
    print(p2)
    p1.move_by(-0.2, 0.4)
    print(p1)
    print(p1.distance_to(p2))



    # p1 = Point(1, 5)
    # print(p1)
    # p2 = Point()
    # p1.move_by(1, 5)
    # print(p1)
    #
    # print(p1.distance_to(p2))

if __name__ == '__main__':
    main()
"""

# """
# from time import sleep
# import time
#
#
# class Clock(object):
#
#     def __init__(self, _hour=0, _minute=0, _second=0):
#         self._hour = _hour
#         self._minute = _minute
#         self._second = _second
#
#     def run(self):
#         """走字"""
#         self._second += 1
#         if self._second == 60:
#             self._second = 0
#             self._minute += 1
#             if self._minute == 60:
#                 self._minute = 0
#                 self._hour += 1
#                 if self._hour == 24:
#                     self._hour = 0
#
#     # 下面的方法可以获得对象的字符串表示形式
#     # 当我们用print打印对象时会自定调用该方法
#     def __str__(self):
#     #def show(self):
#         return '%02d:%02d:%02d' % \
#                (self._hour, self._minute, self._second)
#
#
# # localtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
# # print(localtime)
# # a = int(localtime[11:13])
# # b = int(localtime[14:16])
# # c = int(localtime[17:19])
#
#
# def main():
#     localtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
#     time1 = Clock(localtime[11:13], localtime[14:16], localtime[17:19])
#     while True:
#         print(time1)
#         sleep(1)
#         time1.run()
# """

"""
from time import sleep

class Clock(object):

    def __init__(self, hour=0, minute=30, second=0):
        self.hour = hour
        self.minute = minute
        self.second = second

    def run(self):
        self.second -= 1
        if self.second == -1:
            self.minute -= 1
            self.second = 59


    def __str__(self):
        return ('%02d:%02d:%02d'  % (self.hour, self.minute, self.second))

    def num(self):
        return self.hour * 3600 + self.minute * 60 + self.second + 1

def main():
    time1 = Clock()
    num1 = time1.num()

    for _ in range(num1):
        print(time1)
        sleep(0.0001)
        time1.run()
    print('时间到')


if __name__ == '__main__':
    main()
"""

"""
class Line(object):

    def __init__(self, x1, y1, x2, y2, x3, y3, x4, y4):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
        self.x3 = x3
        self.y3 = y3
        self.x4 = x4
        self.y4 = y4

    def slope(self):
        if self.x2 == self.x1 and self.x4 == self.x3:
            return True
        elif (self.x2 == self.x1 and self.x4 != self.x3) \
                or (self.x2 != self.x1 and self.x4 == self.x3):
            return False
        else:
            k1 = (self.y2 - self.y1) / (self.x2 - self.x1)
            k2 = (self.y4 - self.y3) / (self.x4 - self.x3)
            if k1 == k2 :
                return True
            else:
                return False

def main():
    coord1 = Line(10, 12, 10, 5, 12, 8, 12, 4)
    print(coord1.slope())


if __name__ == '__main__':
    main()
"""

"""
import random

class guess(object):

    def number(self):
        answer = random.randint(1, 100)
        total = 0
        while True:
            total += 1
            if number > answer:
                print('小一点')
            elif number < answer:
                print('大一点')
            else:
                print('恭喜你')
        if total > 7:
            print('智商着急')

def main():
    pass


if __name__ == '__main__':
    main()
"""

"""
def main():
    num = int(input('Number of rows: '))
    yh = [[]] * num
    for row in range(len(yh)):
        yh[row] = [None] * (row + 1)
        for col in range(len(yh[row])):
            if col == 0 or col == row:
                yh[row][col] = 1
            else:
                yh[row][col] = yh[row - 1][col] + yh[row - 1][col - 1]
            print(yh[row][col], end='\t')
        print()


if __name__ == '__main__':
    main()
"""





