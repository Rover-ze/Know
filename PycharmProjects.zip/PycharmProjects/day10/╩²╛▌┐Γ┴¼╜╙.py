import pymysql

# 1.连接到数据库
db = pymysql.Connect(
    host='localhost',
    user='root',
    password='123456',
    db='choice',
    port=3306,
    charset='utf8'
)
# 2.获取游标: 使用 cursor() 方法创建一个游标对象 cursor
cursor = db.cursor()

# 3.执行结果: 使用 execute()  方法执行 SQL 查询
cursor.execute("select * from TbStudent")

# 4.获取结果: 使用 fetchall() 方法获取所有数据.
data = cursor.fetchall()

# 获取一条结果: : 使用 fetchone() 方法获取单条数据.
# data1 = cursor.fetchone()

for i in data:
    print('id:%s name:%s' % (i[0], i[1]))

# 6.关闭数据库连接
db.close()
