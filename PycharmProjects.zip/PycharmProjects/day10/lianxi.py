class Rectangle(object):
    """
    构造器
    """

    def __init__(self, _length, _broad):
        """
        构造器

        :param _length:
        :param _broad:
        """
        self._length = _length
        self._broad = _broad

    def area(self):
        """
        计算面积

        :return:
        """
        return self._length * self._broad

    def perimeter(self):
        """
        计算周长

        :return:
        """
        return (self._broad + self._length) * 2


# def main():
#     rect1 = Rectangle(4, 5)
#     print(rect1.area())
#     print(rect1.perimeter())
#     rect2 = Rectangle(2, 15)
#     print(rect2.area())
#     print(rect2.perimeter())



from time import sleep


class Clock(object):

    def __init__(self, _hour=0, _minute=0, _second=0):
        self._hour = _hour
        self._minute = _minute
        self._second = _second

    def run(self):
        """走字"""
        self._second += 1
        if self._second == 60:
            self._second = 0
            self._minute += 1
            if self._minute == 60:
                self._minute = 0
                self._hour += 1
                if self._hour == 24:
                    self._hour = 0

    # 下面的方法可以获得对象的字符串表示形式
    # 当我们用print打印对象时会自定调用该方法
    def __str__(self):
    #def show(self):
        return '%02d:%02d:%02d' % \
               (self._hour, self._minute, self._second)


def main():
    time1 = Clock(14, 23, 55)
    while True:
        print(time1)
        sleep(1)
        time1.run()


if __name__ == '__main__':
    main()
