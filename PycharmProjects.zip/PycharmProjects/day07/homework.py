# 生成一个指定数的验证码
# 提取文件后缀名
# 写一个能生成随机文件名的函数
# 列表：


from random import randint, choice


# def code(n=4):
#     for _ in range(n):
#         str1 = str(chr(randint(48, 57)))
#         str3 = str(chr(randint(97, 122)))
#         str2 = str(chr(randint(65, 90)))
#         str4 = str1 + str2 + str3
#         str5 = choice(str4)
#
#         print(str5, end='')
#
#
# if __name__ == '__main__':
#     code()


def code(n=4):
    """

    生成指定长度的验证码

    :param n:验证码长度

    :return:由大小写字母及数字构成的随机验证码
    """
    all_chars = '0123456789qwertyuioplkjhgfdsazxcvbnmZXCVBNMLKJHGFDSAQWERTYUIOP'
    last_pos = len(all_chars) - 1
    code = ''
    for _ in range(n):
        index = randint(0, last_pos)
        code += all_chars[index]
    return code


"""
def suffix():
    str1 = input('请输入文件名字：')
    print(str1[str1.rfind('.'):])


if __name__ == '__main__':
    suffix()

"""


def get_suffix(filename, has_dot = False):
    """
    获取文件名的后缀名

    :param filename: 文件名
    :param has_dot: 后缀名是否带 .

    :return: 文件的后缀名
    """
    pos = filename.rfind('.')
    if 0 < pos < len(filename) - 1:
        index = pos if has_dot else pos + 1
        return filename[index:]
    else:
        return ''


if __name__ == '__main__':
    print(get_suffix('1234.txt'))
    print(get_suffix('12345.py', True))
