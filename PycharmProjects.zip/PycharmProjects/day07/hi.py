from random import randint


def code(n=4):
    """

    生成指定长度的验证码

    :param n:验证码长度

    :return:由大小写字母及数字构成的随机验证码
    """
    all_chars = '0123456789qwertyuioplkjhgfdsazxcvbnmZXCVBNMLKJHGFDSAQWERTYUIOP'
    last_pos = len(all_chars) - 1
    code = ''
    for _ in range(n):
        index = randint(0, last_pos)
        code += all_chars[index]
    return code


if __name__ == '__main__':
    print(code(5))



