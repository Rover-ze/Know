# # 欢迎来到成都前锋学习。。。。。。。
#
# import os
# import time
#
#
# str1 = '欢迎来到成都千锋学习。。。。。。。'
# str2 = str1[:]
# for _ in range(1000):
#     os.system('cls')
#     print(str1)
#     time.sleep(0.5)
#
#     str1 = str1[1:] + str1[0]




from random import choice

str1 = '1234567890'
str2 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'

print(choice('str1' + 'str2'))

print(ord('0'))
print(ord('9'))
print(ord('A'))
print(ord('Z'))