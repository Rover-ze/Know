# 函数的递归调用
# 1、收敛条件 -- 让递归在有限次数完成或者回溯
# 如果递归条件无法在有限次数内收敛就有可能导致RecursionError
# 2、递归公式

"""
def f(n):
    if n == 0 or n == 1:
        return 1
    return n * f(n - 1)


print(f(32))

"""

"""
def gcd(x, y):
    if x > y:
        return gcd(y, x)
    elif y % x == 0:
        return x
    else:
        return gcd(y % x, x)
"""

"""
# 1到100求和
def f(n):
    if n == 1:
        return 1
    return (n + f(n - 1))

if __name__ == '__main__':
    print(f(100))
"""

"""
# 上楼，10级台阶，每次1、2、3阶，问多少种走法。
from random import randint


def f(x):
    if x < 0:
        return 0
    elif x == 0:
        return 1
    return f(x - 3) + f(x - 2) + f(x - 1)


if __name__ == '__main__':
    print(f(10))

"""




