

def main():
    help(str.isalnum)         # 查询用法
    # 不变字符串
    str1 = 'hello, world!'
    print(len(str1))          # 打印字符串长度
    print(str1.upper())       # 字符串变大写
    print(str1.capitalize())  # 字符串首字母大写
    print(str1.find('or'))    # 查找字符串中有没有字符‘or’，打印出的是字符串的位置数
    print(str1.find('shit'))  # 查找字符串中有没有字符‘shit’，没有打印为-1
    print(str1.index('or'))
    print(str1.startswith('he'))  # 检查字符串是不是以什么开头的,什么结尾的（检查文件后缀）
    print(str1.endswith('rld!'))  #检查文件是不是‘rld！’结尾的
    print(str1.center(50, '*'))   # 居中，50个字符，不够用*填充（文章排版）
    print(str1.rjust(50, '*'))    # 向左，向右为  r---
    str2 = 'abc123456'
    print(str2[2])              # 取出第2位字符，为c
    print(str2[2:7])            # 取出字符‘c12345’
    print(str2[2:])             # 打印从第二个字符及其之后的字符
    print(str2[2::2])           # 从第二个字符起，每两个取一个
    print(str2[:])              # 打印字符串
    print(str2[::2])            # 从开始，隔一个取一个。
    print(str2[::-1])           # 实现字符串倒转操作
    print(str2[-1])             # 取最后一个字符
    print(str2[-1:-3:-1])       # 负数表示倒着取，-1表示倒着数
    print(str2[-3:-1])          # 从倒数第三个取，取-3--1个
    # 字符串切片处理。
    print(str2.isdigit())       # 判断是不是都是数字
    print(str2.isalpha())       # 判断是不是都是字母
    print(str2.isalnum())       # 判断是不是由字母与数字组成
    str3 = '   jack123@126.com  '


if __name__ == '__main__':
    main()
