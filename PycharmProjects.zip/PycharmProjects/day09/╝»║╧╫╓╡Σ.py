def main():
    list1 = [1, 1, 2, 2, 3, 3]   # 列表
    print(list1)
    tuple1 = (1, 1, 2, 2, 3, 3)  # 元组
    print(tuple1)
    set1 = {1, 1, 2, 2, 3, 3}    # 集合
    print(set1)

    set1.add(6)       # 添加元素至集合
    print(set1)
    set2 = {1, 3, 5, 7, 9}
    print(set2)
    set3 = set1 & set2
    #set3 = set1.intersection(set2)  # 交集 set3 = set1 & set2
    print(set3)
    set3 = set1 | set2
    #set3 = set1.union(set2)         # 并集 set3 = set1 | set2
    print(set3)
    set3 = set1 - set2
    #set3 = set1.difference(set2)    # 差集（set1有set2没有）
    print(set3)
    set3 = set1 ^ set2
    #set3 = set2.difference(set1)    # 差集（set2有set1没有）
    print(set3)
    set3 = set1.symmetric_difference(set2)  # 对称集（去重）
    print(set3)

    # 集合是离散存取的，是无序的，不能用下标进行取元素
    for val in set2:
        print(val)
    if 3 in set2:
        set2.remove(3)
    print(set2)
    print(set2.issubset(set1))
    print(set1.issuperset(set2))
    set4 = {1, 2}
    print(set)


# 集合的排序：


def foo():
    set1 = {'hello', 'good', 'banana', 'zoo', 'Python'}
    print(len(set1))
    x = sorted(set1)
    print(type(x))
    print(x)
    list(x)
    list1 = list(set1)
    print(list1)


# 字典：


def g():
    dict1 = {'name': '王大锤', 'age': '28'}
    print(dict1['name'])
    print(dict1['age'])
    dict1['name'] = '周星星'   # 修改
    print(dict1)
    # dict1 += {'tel': '1351122334455'}
    for x in dict1:
        print(x)
        print(x, '--->', dict1[x])
    dict1.update(height=178, fav=['吃', '喝'])  # 添加
    print(dict1)
    print(dict1.pop('age'))    # 删除
    print(dict1.popitem())     # 删除
    dict1['name'] = None       # 删除
    print(dict1)
    del dict1['name']
    print(dict1)
    dict1.setdefault('motto', '0000000')       # 设置默认值
    print(dict1)







if __name__ == '__main__':
    g()

f = [1, 2, 3, 4]
print(f[0])