def main():
    list1 = [1, 6, 15, 20, 15, 6, 1]

    for index in range(len(list1)):

        if index == 0:
            y = list1[index]
        else:
            y1 = list1[index + 1]
            y2 = list1[index]
            y = y1 + y2
        list1.append(y)
        # for _ in range(3):
        #     list1.remove(list1[0])
    print(list1)





# def yanghui_trangle(n):
#     def _yanghui_trangle(n, result):
#         if n == 1:
#             return [1]
#         else:
#             return [sum(i) for i in zip([0] + result, result + [0])]
#     pre_result = []
#     for i in range(n):
#         pre_result = _yanghui_trangle(i + 1, pre_result)
#         yield pre_result
#
#
#
#
# if __name__ == "__main__":
#     for line in yanghui_trangle(10):
#         print(line)




"""
#生成器生成展示杨辉三角
#原理是在一个2维数组里展示杨辉三角，空的地方用0，输出时，转化为' '
def yang(line):
  n,leng=0,2*line - 1
  f_list = list(range(leng+2)) #预先分配，insert初始胡会拖慢速度，最底下一行，左右也有1个空格
  #全部初始化为0
  for i,v in enumerate(f_list):
    f_list[v] = 0
  ZEROLIST = f_list[:] #预留一个全零的数组
  f_list[leng//2] = 1 #初始的第一行
  re_list =f_list[:]
  n=0
  while n < line:

    n = n+1
    yield re_list
    f_list,re_list = re_list[:],ZEROLIST[:]
    start = leng//2-n         #计算一行中第一个1的位置
    end = start + 2*n         #计算一行中最后一个1的位置
    while start <= end:
      re_list[start] = f_list[start - 1] + f_list[start+1] #不管是不是1，该位置的数字，都是上一行该位置的左右两个数的和
      start = start + 1
  return 'done'

def printList(L):
  n = 0
  p_str = ''
  for value in L:
    ch = str(value)
    if value == 0:
      ch = ' '
    p_str = p_str + ch
  print(p_str)

for value in yang(8):
  printList(value)
"""



#
# def f():
#     list1 = [1]
#     while True:
#         yield list1
#         list1 = [list1[x] + list1[x + 1] for x in range(len(list1) - 1)]
#         list1.insert(0, 1)
#         list1.append(1)
#
#         if len(list1) > 10:
#             break
#
#
# a = f(10)
# for y in a:
#     print(a)







