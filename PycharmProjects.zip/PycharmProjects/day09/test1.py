def main():
    names = ['关羽', '张飞', '赵云', '马超', '貂蝉']
    subjects = ['语文', '数学', '英语']
    table = []
    # table = [[0 for _ in range(3)] for _ in range(5)]
    for row, name in enumerate(names):
        input('请输入%s的成绩：' % name)
        scores = []
        for col, subject in enumerate(subjects):
            score = int(input('%s:' % subject))
            scores.append(score)
        table.append(scores)
    print(table)


def foo():
    names = ['关羽', '张飞', '赵云', '马超', '貂蝉']
    subjects = ['语文', '数学', '英语']
    table = [[0 for _ in range(3)] for _ in range(5)]
    for row, name in enumerate(names):
        input('请输入%s的成绩：' % name)
        for col, subject in enumerate(subjects):
            score = int(input('%s:' % subject))
            table[row][col] = score
    print(table)



if __name__ == '__main__':
    main()