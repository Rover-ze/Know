import pymysql

# 1.连接到数据库
db = pymysql.Connect(
    host='localhost',
    user='root',
    password='123456',
    db='choice',
    port=3306,
    charset='utf8'
)
# 2.获取游标
cursor = db.cursor()

# 3.执行结果
sql = 'select * from TbStudent'
cursor.execute(sql)

# 4.获取结果
data = cursor.fetchall()

# # 5.获取一条结果
# data1 = cursor.fetchone()

for i in data:
    print('id:%s name:%s' % (i[0], i[1]))

db.close()
