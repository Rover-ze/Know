class Rect(object):

    def __init__(self, width, height):
        self._width = width
        self._height = height

    @property
    def width(self):
        return self._width

    @width.setter
    def width(self, width):
        self._width = width if width > 0 else 0

    @property
    def height(self):
        return self._height

    @height.setter
    def height(self, height):
        self._height = height if height > 0 else 0

    @property
    def area(self):
        return self._width * self._height

    @property
    def perimeter(self):
        return (self._width + self._height) * 2


def main():
    rect1 = Rect(2, 5)
    print(rect1.area)
    print(rect1.perimeter)


if __name__ == '__main__':
    main()