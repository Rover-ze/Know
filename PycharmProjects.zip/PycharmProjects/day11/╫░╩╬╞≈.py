def record(fn):
    def wrapper(*args, **kwargs):
        print('准备执行%s函数' % fn.__name__)
        print(args)
        print(kwargs)

        #
        #
        #
        val = fn(*args, **kwargs)

        print('%s函数执行完成' % fn.__name__)
        print('函数%d' % val)
        #
        return val
    return wrapper


# 通过装饰器修饰f函数  让f函数在执行过程中可以做到更多额外的操作
@record
def f(n):
    if n == 0 or n == 1:
        return 1
    return n * f(n - 1)

@record
def add(x, y):
    return x + y


if __name__ == '__main__':
    # print(add(1, 2))
    print(f(5))