# 关键字参数（**kwargs） -- 把参数组装成字典 -- 根据参数名来决定如何执行
# 随机参数(*args) -- 元组
# 命名关键字参数 --
# decorator -- 装饰器 / 包装器


# 高阶函数 y = f(g(x))

# 高内聚  低耦合
# high cohesion low coupling

# 通过向函数中传入函数，可以写出更通用的代码
# calc函数中的第二个参数是另一个函数  它代表一个二元运算
# 这样的calc函数就不需要根某一种特定的二元运算耦合在一起
# 所以calc函数变得通用性更强，可以由传入的第二个参数来决定到底做什么
def calc(my_list, op):
    total = my_list[0]
    for index in range(1, len(my_list)):
        total = op(total, my_list[index])
    return total


def mul(x, y):
    return x + y


def add(x, y):
    return x * y


def main():
    mylist = [1, 2, 3, 4, 5]
    print(calc(mylist, add))
    print(calc(mylist, mul))


def say_hello(**kwargs):
    if 'name' in kwargs:
        print('你好，%s!' % kwargs['name'])
    elif 'age' in kwargs:
        age = kwargs['age']
        if age <= 16:
            print('你还是个小屁孩')
        else:
            print('你是一个成年人')
    else:
        print('请提供个人信息！')


def my_sum(*args):
    total = 0
    for x in args:
        total += x
    return total


def foo(a, b, c, *, name, age):
    print(a + b + c)
    print(name, ':', age)


def main():
    say_hello()
    say_hello(name='王大锤')
    say_hello(name='王大锤', age=16)
    say_hello(age=17)
    param = {'name': '周星星', 'age': 16}
    # 如果希望将一个字典作为关键字参数传入，那么需要在参数前放两个**
    say_hello(**param)

    my_list = [1, 2, 3, 4, 5]
    # 如果希望将元组或列表作为可变参数传入，需要在参数名前面加*
    print(my_sum(*my_list))

    foo(1, 2, 3, name='诸葛', age=18)


if __name__ == '__main__':
    main()


