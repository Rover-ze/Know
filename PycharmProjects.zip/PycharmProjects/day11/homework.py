# 公司工资结算系统
# 1、部门经理 -- 每月一万五
# 2、程序员每小时150
# 3、销售，底薪1200，提成百分之5

"""
class Employee(object):

    def __init__(self, name, post):
        self._name = name
        self._post = post

    @property
    def post(self):
        return self._post

    @post.setter
    def post(self, post):
        self._post = post


class Manager(Employee):

    def __init__(self, name, post):
        super().__init__(name, post)

    def __str__(self):
        return '%s : %s : 薪水为 15000' % (self._name, self._post)

class Programmer(Employee):

    def __init__(self, name, post,  time):
        super().__init__(name, post)
        # self._salary = salary
        self._time = time

    @property
    def salary(self):
        return self._time * 150

    def __str__(self):
        return '%s : %s : 薪水为 % d' % (self._name, self._post, self._time * 150)


class Salesman(Employee):

    def __init__(self, name, post, saleroom):
        super().__init__(name, post)
        self._saleroom = saleroom

    @property
    def saleroom(self):
        return self._saleroom * 0.05 + 1200

    def __str__(self):
        return '%s : %s : 薪水为 % d' % (self._name, self._post, self._saleroom * 0.05 + 1200)


def main():
    emps =[
        Manager('刘备'), Programmer('诸葛亮'),
        Manager('曹超'), Salesman('荀彧'),
        Salesman('吕布'), Programmer('张辽'),
        Programmer('赵云')
    ]
    for emp in emps:
        if isinstance(emp, Programmer):
        # isinstance函数
            emp.working_hour = int(input('请输入%s本月工作时间：' % emp.name))
        elif isinstance(emp, Salesman):
            emp.salas = float(input('请输入%s本月销售额：' % emp.name))

        # 多态行为
        # 同样是接受get_salary这个消息，但是不同的员工表现出不同的行为
        # 因为三个子类都重写了get_salary方法，所以这个方法会表现出多态行为

        print('%s本月工资为：￥%.2f' %
              (emp.name, emp.get_salary()))


if __name__ == '__main__':
    main()
"""



# python没有从语言层面支持抽象概念
# 我们可以通过abc模块来制造抽象类的效果
# 在定义类的时候通过指定mataclass=ABCMeta可以将类声明为抽象类
# 抽象类是不能创建对象的， 抽象类存在的意义是专门拿给其他类继承
# abc模块中还有一个

from abc import ABCMeta, abstractmethod



class Employee(object):
    """员工"""

    def __init__(self, name):
        """
        初始化方法

        :param name: 员工名字
        """
        self._name = name

    @property
    def name(self):
        return self._name

    @abstractmethod
    def get_salary(self):
        """
        获得月薪

        :return: pass
        """
        pass


class Manager(Employee):
    """经理"""

    def get_salary(self):
        """
        经理获得的工资

        :return: 工资
        """
        return 15000


class Programmer(Employee):

    def __init__(self, name):    # def __init__(self, name, working_hour=0):
        # 非必要的元素可以不再这儿体现，用访问器、修改器录入
        super().__init__(name)
        self._working_hour = 0   # self._working_hour = working_hour

    @property
    def working_hour(self):
        return self._working_hour

    @working_hour.setter
    def working_hour(self, working_hour):
        self._working_hour = working_hour \
            if working_hour > 0 else 0

    def get_salary(self):
        return 150 * self._working_hour


class Salesman(Employee):

    def __init__(self, name):
        super().__init__(name)
        self._salas = 0

    @property
    def salas(self):
        return self._salas

    @salas.setter
    def salas(self, salas):
        self._salas = salas if salas > 0 else 0

    def get_salary(self):
        return 1200 + self._salas * 0.05


def main():
    emps =[
        Manager('刘备'), Programmer('诸葛亮'),
        Manager('曹超'), Salesman('荀彧'),
        Salesman('吕布'), Programmer('张辽'),
        Programmer('赵云')
    ]
    for emp in emps:
        if isinstance(emp, Programmer):
        # isinstance函数
            emp.working_hour = int(input('请输入%s本月工作时间：' % emp.name))
        elif isinstance(emp, Salesman):
            emp.salas = float(input('请输入%s本月销售额：' % emp.name))

        # 多态行为
        # 同样是接受get_salary这个消息，但是不同的员工表现出不同的行为
        # 因为三个子类都重写了get_salary方法，所以这个方法会表现出多态行为

        print('%s本月工资为：￥%.2f' %
              (emp.name, emp.get_salary()))


if __name__ == '__main__':
    main()