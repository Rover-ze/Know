class Teacher(object):

    def __init__(self, name, age, do):
        self._name = name
        self._age = age
        self._do = do

    @property
    def name(self):
        return self._name

    @property
    def age(self):
        return self._age

    @age.setter
    def age(self, age):
        self._age = age if (23 <= age <= 60) else 30

    @property
    def do(self):
        return '上课'


def main():
    teacher1 = Teacher('王大锤', 30, ' ')
    print(teacher1.name)
    print(teacher1.do)


if __name__ == '__main__':
    main()

