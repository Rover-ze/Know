from urllib import parse, request
import json

from mongoengine import ValidationError

textmod = {"id": "12", "productID": 123, "quaily": 1}
textmod = json.dumps(textmod).encode(encoding='utf-8')
header_dict = {'access-token': '1111',
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',
               "Content-Type": "application/json"}
url = 'http://rcapiext-qa.rcmart.com/v1/account/token'
req = request.Request(url=url, data=textmod, headers=header_dict)
try:
    res = request.urlopen(req)
    res = res.read()
    print(res.decode(encoding='utf-8'))
except ValidationError:
    print('参数类型错误')
