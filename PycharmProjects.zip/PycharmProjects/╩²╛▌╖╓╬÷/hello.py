from urllib import parse, request

header_dict = {'access-token': '1111',
               'language': 'zh_cn',
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',
               "Content-Type": "application/json"}
url = 'http://rcapiext-qa.rcmart.com/v1/account/token'
req = request.Request(url=url, headers=header_dict, method='POST')
res = request.urlopen(req)
res = res.read()
print(res.decode(encoding='utf-8'))
