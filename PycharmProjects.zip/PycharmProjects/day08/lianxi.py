"""
# fibonacci序列[1, 1, 2, 3, 5, 8, 13, 21, ....]
def main():
    f = [1, 1]

    for index in range(2, 20):
        val = f[index - 1] + f[index - 2]
        f.append(val)
    f2 = f[18:]
    f3 = f[::-1]
    print(f)
    print(f2)
    print(f3)
    f.reverse()
    print(f)


if __name__ == '__main__':
    main()
"""


# 列表中的最大、最小、平均数
# 按照单词长短排序。




"""
def main():
    scores = [95, 5, 18, 20, 50]
    min_score = max_score = scores[0]
    total = 0
    for score in scores:
        if score < min_score:
            min_score = score
        elif score > max_score:
            max_score = score
        total += score
    print('最高分：', min_score)
    print('最低分：', max_score)
    print('平均分：', total / len(scores))




    f = ['red', 'blue', 'zoo', 'orange', 'internationalization', 'blueberry']
   # print(len(f[0]))

    f1 = sorted(f, key=len)
    f2 = sorted(f, key=len, reverse=True)
    print(f1)
    print(f2)


if __name__ == '__main__':
    main()
"""
# from random import randint,choice
#
#
# def foo():
#     red_ball = list(range(1, 34))
#     blue_ball = list(range(1, 17))
#     f = []
#     for _ in range(6):
#         red_ball1 = choice(red_ball)
#         f.append(red_ball1)
#         red_ball.remove(red_ball1)
#         f.sort()
#     f.append(choice(blue_ball))
#
#     return f
#
#
# def main(n):
#     n = int(input('maijizhu: '))
#     for _ in range(n):
#         return (foo())
#
#
# if __name__ == '__main__':
#     print(main(5))


# 双色球：
from random import randrange,randint


def display(balls):
    for index, ball in enumerate(balls):
        if index == len(balls) - 1:
            print('|', end=' ')
        print('%02d' %ball, end=' ')
    print()


def random_select():
    red_balls = list(range(1, 34))
    selected_balls = []
    for _ in range(6):
        index = randrange(len(red_balls))
        selected_balls.append(red_balls[index])
        del red_balls[index]
    selected_balls.sort()
    selected_balls.append(randint(1, 16))
    return selected_balls


def main():
    n = int(input('机选几注：'))
    for _ in range(n):
        display(random_select())


if __name__ == '__main__':
    main()






