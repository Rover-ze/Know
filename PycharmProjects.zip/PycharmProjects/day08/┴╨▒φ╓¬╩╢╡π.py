import sys     # 计算机系统模块


def main():
    f = [100, 200, 500]
    for index, val in enumerate(f):  # 枚举
        print(index, ':', val)
        print(val)
    # CRUD操作  Create
    f.append(123)      # 追加
    f.insert(1, 321)   # 插入, 1表示位置
    if 500 in f:       # 检查列表容器中是否有500
        f.remove(500)  # 删除
    del f[3]           # 删除列表中知道位置的元素（知道位置用del，
                       # 知道有元素用remove。不知道有没有，用if判断。）
    f.pop(1)           # 删除指定下标位置元素，默认为删除最后一个元素
    #f.clear()          # 清空
    f.index(100)       # 查找元素位置，返回位置数
    f.reverse()        ## 翻转列表，改变的是列表。

    f = f + [20, 30]   # 列表中添加元素
    f[::1]     # 列表切片处理，提取列表中元素，1表示步距

    print(f)


    # 排序：python中默认的排序都是升序，
    # 如果希望排列成降序（从大到小），可以通过reverse参数来指定。
    # python中的函数几乎都是没有副作用的函数
    #调用函数后不会影响传入的参数
    f1 = sorted(f)
    f2 = sorted(f, reverse=True)
    print(f1)
    print(f2)
    f.sort()         # 直接对f排序（升序）
    f.sort(reverse=True)  #降序
    print(f)
    f.reverse()      # 反转f列表
    f3 = reversed(f)  # 反转列表f
    f4 = list(reversed(f))
    print(f3)
    print(f4)

# 计算机中，时间和空间是不可调和的矛盾。
# 软件和硬件在逻辑上是等效的

    # 创建列表：生成式：用列表的生成表达式语法创建列表容器
    # 用这种语法创建列表之后元素已经准备就绪所以需要耗费较多的内存空间
    f = list(range(1, 10))
    f1 = [x for x in range(1, 10)]
    print(f)
    print(f1)

    f = [x ** 2 for x in range(1, 10)]
    f1 = [x ** x for x in range(1, 10)]
    print(f)
    print(f1)
    print(sys.getsizeof(f))

    # 创建列表：生成器：得到的不是一个列表，而是一个生成器对象
    # 通过生成器可以获取到数据，它不占用额外的空间储存数据
    # 每次需要数据的时候就通过生成器取数据，这需要花费时间。
    f = (x ** 2 for x in range(1, 10))
    print(sys.getsizeof(f))
    print(f)
    for val in f:
        print(val)


def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
        yield a

for val in fib(20):
    print(val)




    # 有了列表（容器）我们可以使用1个变量来保存多个数据
    # 更为重要的是我们可以使用循环对列表中保存的数据进行操作


    # 组合运算
f = [x + y for x in 'ABCDE' for y in '1234']
print(f)





if __name__ == '__main__':
    main()



