# 设计一个函数计算传入的成绩列表平均数，要求去掉一个最高分，一个最低分
# 输入成绩，找出成绩最高和最低的人
# 从一个列表中找出第二大元素，只能用一次循环


"""
def main():
    scores = [1,2,3,4,5,6]
   # min_score = max_score = scores[0]
    total = 0

    # for score in scores:
    #     if min_score > score:
    #         min_score = score
    #     elif max_score < score:
    #         max_score = score
    # scores.remove(min_score)
    # scores.remove(max_score)
    scores.remove(max(scores))
    scores.remove(min(scores))

    for x in scores:
        total += x

    mean_score = total / (len(scores))
    return mean_score


if __name__ == '__main__':
    print(main())
"""



def main():
    scores = [100, 100, 100, 100, 50, 50]
    max_score = scores[0]
    for score in scores:
        if max_score < score:
            max_score = score
    # while True:
    #     if max_score in scores:
    #         scores.remove(max_score)
    #     else:
    #         break

    for _ in range(len(scores)):
        if max_score in scores:
            scores.remove(max_score)

    return max(scores)


if __name__ == '__main__':
    print(main())





def main():
    scores = [100, 75, 100, 80, 50, 50]
    max_score = max(scores)
    for _ in range(len(scores)):
        if max_score in scores:
            scores.remove(max_score)

    return max(scores)



def f(x):
    x = [100, 75, 100, 80, 50, 50]
    (m1, m2) = (x[0], x[1] if x[0] > x[1] else (x[0], x[1]))
    for index in range(2, len(x)):
        if x[index] > m1:
            m2 = m1
            m1 = x[index]
        elif x[index] > m2:
            m2 = x [index]
    return m1, m2


def g():
    my_list = [100, 75, 100, 80, 50, 50]
    print(f(my_list))





if __name__ == '__main__':
    f()











# names = ['刘备', '张飞','曹操', '袁绍', '关羽', '赵云', '周瑜']
# scores = []
# for name in names:
#     score = input('请输入%s的成绩：' % name)
#     scores.append(int(score))
#
#     x = scores.index(max(scores))
#     y = scores.index(min(scores))
#
#     max_num = []
#
#     for _ in range(len(scores)):
#         if x in scores:
#             z = max_num.index(x)
#
# print(names[x], '是成绩最高的人')
# print(names[y], '是成绩最低的人')
# print(z)















