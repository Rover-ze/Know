from random import randint


def roll_dice(n=2):
    """
    摇n颗色子得出的点数
    :param n: 色子的颗数
    :return:
    """
    total = 0
    for _ in range(n):
        total += randint(1, 6)
    return total


def main():
    f = [100, 200, 500]
    for index, val in enumerate(f):
        print(index, ':', val)
    # CRUD操作  Create



    # 有了列表（容器）我们可以使用1个变量来保存多个数据
    # 更为重要的是我们可以使用循环对列表中保存的数据进行操作
    f = [0] * 6
    for _ in range(60000):
        face = randint(1, 6)
        f[face - 1] += 1
    return f


def foo():
    f = [0] * 11
    for _ in range(60000):
        face = roll_dice()
        f[face - 2] += 1
    for index in range(len(f)):
        print('%d出现的概率是%.2f%%'  %(index + 2, f[index] / 600))
    # for index, val in enumerate(f):
    #     print('%d出现的概率是%.2f%%'  %(index + 2, val / 600))


    # 直接通过for-in循环对列表（容器）进行遍历
    for counter in f:
        print(counter)








if __name__ == '__main__':
    foo()