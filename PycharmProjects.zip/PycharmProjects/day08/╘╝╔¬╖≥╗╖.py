# 约瑟夫环：

# def main():
#     f = list(range(1, 31))
#     for _ in range(15):
#         f.pop(8)
#         f1 = f[0:8]
#         f = f + f1
#         for _ in range(8):
#             f.remove(f[0])
#
#     f.sort()
#     print(f)
#
#
# if __name__ == '__main__':
#     main()


def main():
    persons = [True] * 30
    counter = 0   # 死去的人数
    index = 0     # 下标
    number = 0    # 报数
    while counter < 15:
        if persons[index]:
            number += 1
            if number == 9:
                persons[index] = False
                counter += 1
                number = 0
        index += 1
      #  index %= 30
        if index == 30:
            index = 0
    for person in persons:
        print('基' if person else '非', end=' ')

if __name__ == '__main__':
    main()

