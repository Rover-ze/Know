"""
#Craps赌博游戏，游戏规则如下：
# 玩家掷两个骰子，点数为1到6，如果第一次点数和为7或11，则玩家胜，如果点数和为2、3或12，则玩家输，
#如果和 为其它点数，则记录第一 次的点数和，然后继续掷骰，直至点数和等于第一次掷出的点数和，则玩家胜，
#如果在这之前 掷出了点数和为7，则玩家输。


from random import randint

wj = 0
zj = 0

for n in range(100000):
    x = randint(1, 6)
    y = randint(1, 6)
    a = x + y
    go_on = False
    if a == 7 or a == 11:
        wj += 1
    elif a == 2 or a == 3 or a ==12:
        zj += 1
    else:
        go_on = True
    while go_on:
        x1 = randint(1, 6)
        y1 = randint(1, 6)
        b = x1 + y1
        if b == 7:
            zj += 1
            go_on = False
        elif b == a:
            wj += 1
            go_on = False

print(wj, zj)
"""

"""

from getpass import getpass

use_name = input('请输入用户名：')
answer = getpass('请输入密码：')
if use_name == ('admin') and answer == ('123456'):
    print('欢迎使用本系统。')
else:
    print('用户名或密码输入错误。')

"""    # 问题



