"""
Craps赌博游戏，游戏规则如下：
  玩家掷两个骰子，点数为1到6，如果第一次点数和为7或11，则玩家胜，如果点数和为2、3或12，则玩家输，
  如果和 为其它点数，则记录第一 次的点数和，然后继续掷骰，直至点数和等于第一次掷出的点数和，则玩家胜，
  如果在这之前 掷出了点数和为7，则玩家输。

"""

"""
# 错误语法
from random import randint

while True:
    x = randint(1, 6)
    y = randint(1, 6)
    print(x, y)
    if x + y == 7 or x + y == 11:
        print(x + y, '恭喜你。')

    elif x + y == 2 or x + y == 3 or x + y == 12:
        print(x + y, '你输了。')

    else:
        z = x + y
        print(z)
        if x + y == 7:
            print(x + y, '你输了。')
        if z == x + y:
            print(x + y, '恭喜你。')
    break

"""



"""
# 语法错误
from random import randint

x = randint(1, 6)
y = randint(1, 6)
a = x + y
print(a)

if a == 7 or a == 11:
    print(a, '恭喜你。')
elif a == 2 or a == 3 or a == 12:
    print(a, '你输了。')
else:
    True
while True:
    x = randint(1, 6)
    y = randint(1, 6)
    b = x + y
    print(b)
    if b == 7:
        print(b, '你输了。')
        break
    elif b == a:
        print(b, '恭喜你。')
        break
"""




from random import randint


x = randint(1, 6)
y = randint(1, 6)
a = x + y
print(a)
go_on = False
if a == 7 or a == 11:
    print(a, '恭喜你。')
elif a == 2 or a == 3 or a == 12:
    print(a, '你输了。')
else:
    go_on = True
while go_on:
    x = randint(1, 6)
    y = randint(1, 6)
    b = x + y
    print(b)
    if b == 7:
        print(b, '你输了。')
        go_on = False
    elif b == a:
        print(b, '恭喜你。')
        go_on = False



# from random import randint
#
#
# def roll_dice(n):
#     total = 0
#     for _ in range(n):
#         total += randint(1, 6)
#     return total
"""


"""

# n = 3
# money = 1000
#
# # 玩家有钱游戏就可以继续
# while money > 0:
#     print('玩家总资产：', money)
#     # 通过while循环判断玩家下注是否有效。
#     while True:
#         use_money = int(input('请下注：'))
#         if 0 < use_money <= money:
#             break
#
#     a = roll_dice(n)
#     print(a)
#     go_on = False
#     if a == 7 or a == 11:
#         print(a, '恭喜你。')
#         money += use_money
#     elif a == 2 or a == 3 or a == 12:
#         print(a, '你输了。')
#         money = money - use_money
#     else:
#         go_on = True
#     while go_on:
#         b = roll_dice(n)
#         print(b)
#         if b == 7:
#             print(b, '你输了。')
#             money = money - use_money
#             go_on = False
#         elif b == a:
#             print(b, '恭喜你。')
#             money += use_money
#             go_on = False
#     print(money)
#     if use_money > money:
#         print('你没钱了')
