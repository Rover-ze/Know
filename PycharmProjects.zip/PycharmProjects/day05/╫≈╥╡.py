"""

from time import time
from math import sqrt

start = time()
for num in range(2, 10000):
    z = 1
    for x in range(2, int(sqrt(num) + 1)):
        if num % x == 0:
            z += x
            if x != num // x:
                z += num // x
    if z == num:
        print(num)

end = time()
print((end - start), '秒')


"""



for num in range(1, 10000):
    z = 0
    for x in range(1,num):
        if num % x == 0:
            z += x
    if z == num:
        print(num)
