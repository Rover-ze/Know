from socket import socket
from threading import Thread


def main():
    class ClientHandler(Thread):

        def __init__(self, client):
            super().__init__()
            self._client = client

        def run(self):
            try:
                while True:
                    try:  # 查询异常
                        data = self._client.recv(1024)  # 接收消息
                        # self._client.send(data) 发送消息
                        if data.decode('utf-8') == 'byebye':  # 如果说了byebye，主动断开连接
                            clients.remove(self._client)
                            self._client.close()
                            break
                        else:
                            for client in clients:
                                client.send(data)
                    except Exception as e:
                        print(e)
                        clients.remove(self._client)  # 出故障移除
                        break
            except Exception as e:
                print(e)

    server = socket()  # 1创建套接字
    # python命令行参数 -- sys.argv -- 替换端口（端口可变）
    server.bind(('10.7.189.71', 4096))  # 2建立端口
    server.listen(512)  # 3监听
    clients = []  # 5创建列表，容纳每一个客户端
    while True:
        # server.accept() 接收用户消息（阻塞式）返回一个元组
        curr_client, addr = server.accept()  # 4接收用户
        print(addr[0], '连接到服务器.')
        clients.append(curr_client)  # 6
        ClientHandler(curr_client).start()  # 7创建线程、使用线程


if __name__ == '__main__':
    main()
