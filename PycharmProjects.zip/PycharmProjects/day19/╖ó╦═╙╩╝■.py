from smtplib import SMTP
from email.mime.text import MIMEText


def main():
    sender = SMTP('smtp.163.com')
    sender.login('18380498522@163.com', 'xz102887')

    content = """
    fuck
    """

    # MIME -- Multipurpose Internet Mail Extension
    message = MIMEText(content, 'plain', 'utf-8')
    message['Subject'] = '狗屎'

    sender.sendmail('18380498522@163.com', ['1028877892@qq.com'],
                    message.as_string())
    print('发送完成！')


if __name__ == '__main__':
    main()


    