import re


def main():
    # substitute -- 替换
    sentence = 'hello world!'
    pure = re.sub('[ ]|[h]', '*', sentence, flags=re.IGNORECASE)
    # 把hello world！ 中的空格和h替换成*符号。
    # flags=re.IGNORECASE  标记，忽略大小写
    print(pure)


if __name__ == '__main__':
    main()
