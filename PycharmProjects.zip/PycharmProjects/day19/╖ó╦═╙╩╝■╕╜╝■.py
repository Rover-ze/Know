from smtplib import SMTP
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


def main():
    sender = SMTP('smtp.163.com')
    sender.login('18380498522@163.com', 'xz102887')

    message = MIMEMultipart()
    message['Subject'] = '请查收'
    text_msg = MIMEText('附件中有本月相关数据请查收', 'plain', 'utf-8')
    message.attach(text_msg)

    att2 = MIMEText(open('123.xls', 'rb').read(), 'base64', 'utf-8')
    att2['Content-Type'] = 'application/octet-stream'  # 注意mime类型
    att2['Content-Disposition'] = 'attachment; filename=456.xls'
    message.attach(att2)

    sender.sendmail('18380498522@163.com', ['18380498522@163.com'],
                    message.as_string())
    print('发送完成！')


if __name__ == '__main__':
    main()